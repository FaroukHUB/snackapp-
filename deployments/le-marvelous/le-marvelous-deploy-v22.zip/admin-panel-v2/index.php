<?php
/**
 * SnackApp v1 - Admin Dashboard
 * Support MySQL avec fallback JSON
 */


require_once __DIR__ . '/../database/repositories/LoyaltyRepository.php';
require_once __DIR__ . '/bootstrap.php';
requireAdmin();

$useMySQL = !SNACK_USE_JSON && !defined('SNACK_DB_ERROR');

// ============================================
// CHARGER LES DONNÉES
// ============================================

if ($useMySQL) {
    // Mode MySQL
    $restaurant = getCurrentRestaurant();
    $restaurantName = $restaurant['name'] ?? 'Restaurant';
    $primaryColor = $restaurant['primary_color'] ?? '#c58a3a';

    // Toujours charger les settings depuis restaurant.json (source de vérité)
    $restaurantSettings = json_decode(file_get_contents(__DIR__ . '/../config/restaurant.json'), true) ?? [];
    $orders = OrderRepository::getActiveOrders(SNACK_RESTAURANT_ID, 50);
    $archivedOrders = OrderRepository::getArchivedOrders(SNACK_RESTAURANT_ID, 500);
    $customers = CustomerRepository::getAll(SNACK_RESTAURANT_ID);
    $stats = OrderRepository::getTodayStats(SNACK_RESTAURANT_ID);

    // Auto-archive des commandes > 24h
    OrderRepository::autoArchive(SNACK_RESTAURANT_ID);

    // Formater les commandes pour compatibilité template
    foreach ($orders as &$o) {
        $o['id'] = $o['order_number'] ?? $o['id'];
    }
    foreach ($archivedOrders as &$o) {
        $o['id'] = $o['order_number'] ?? $o['id'];
    }

    // Menu categories
    $menuData = MenuRepository::getFullMenu(SNACK_RESTAURANT_ID);
    $products = $menuData['menu']['categories'] ?? [];

    // Settings pour les formulaires
    $settings = RestaurantRepository::getSettings(SNACK_RESTAURANT_ID);
    $openingHours = RestaurantRepository::getOpeningHours(SNACK_RESTAURANT_ID);
    $faqItems = RestaurantRepository::getFaq(SNACK_RESTAURANT_ID);
    $whatsappConfig = RestaurantRepository::getWhatsAppConfig(SNACK_RESTAURANT_ID);

    // Stats avancées
    $weekStats = OrderRepository::getWeekStats(SNACK_RESTAURANT_ID);
    $monthStats = OrderRepository::getMonthStats(SNACK_RESTAURANT_ID);
    $topProducts = OrderRepository::getTopProducts(SNACK_RESTAURANT_ID, 30, 5);
    $peakHours = OrderRepository::getPeakHours(SNACK_RESTAURANT_ID, 30);
    $dailyRevenue = OrderRepository::getDailyRevenue(SNACK_RESTAURANT_ID, 7);
    
    // Données fidélité
     $loyaltyConfig = LoyaltyRepository::getConfig(SNACK_RESTAURANT_ID);
     $loyaltyRewards = LoyaltyRepository::getAllRewards(SNACK_RESTAURANT_ID);
     $loyaltyLeaderboard = LoyaltyRepository::getLeaderboard(SNACK_RESTAURANT_ID, 10);


} else {
    // Mode JSON (fallback)
    require_once __DIR__ . '/config.php';

    $config = loadConfig();
    $restaurantName = $config['restaurant']['name'] ?? $config['name'] ?? 'Restaurant';
    $primaryColor = $config['branding']['primaryColor'] ?? $config['theme']['colors']['brand'] ?? '#c58a3a';

    $restaurantSettings = json_decode(file_get_contents(__DIR__ . '/../config/restaurant.json'), true) ?? [];
    $orders = loadData('orders.json') ?? [];
    $archivedOrders = loadData('orders-archive.json') ?? [];
    $customers = loadData('customers.json') ?? [];

    // Auto-archive JSON
    $now = time();
    $archiveThreshold = 24 * 60 * 60;
    $ordersToKeep = [];

    foreach ($orders as $order) {
        $orderTime = strtotime($order['created_at'] ?? '');
        if ($orderTime && ($now - $orderTime) > $archiveThreshold && ($order['status'] ?? '') === 'completed') {
            $archivedOrders[] = $order;
        } else {
            $ordersToKeep[] = $order;
        }
    }

    if (count($ordersToKeep) !== count($orders)) {
        $orders = $ordersToKeep;
        saveData('orders.json', $orders);
        saveData('orders-archive.json', $archivedOrders);
    }

    // Trier et limiter
    usort($orders, fn($a, $b) => strtotime($b['created_at']) - strtotime($a['created_at']));
    $orders = array_slice($orders, 0, 50);

    // Stats JSON
    $today = date('Y-m-d');
    $stats = ['pending' => 0, 'completed' => 0, 'today' => 0, 'revenue' => 0];
    foreach ($orders as $order) {
        if (strpos($order['created_at'], $today) === 0) {
            $stats['today']++;
            $stats['revenue'] += $order['total'] ?? 0;
        }
        $stats[($order['status'] ?? 'pending') === 'completed' ? 'completed' : 'pending']++;
    }

    $products = $config['menu']['categories'] ?? [];
    $openingHours = $restaurantSettings['openingHours'] ?? [];
    $faqItems = $restaurantSettings['faq']['items'] ?? [];
    $whatsappConfig = $restaurantSettings['whatsapp'] ?? [];
    $settings = $restaurantSettings;
}

// ============================================
// TRAITER LES ACTIONS POST
// ============================================

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
$action = $_POST['action'];

    // === GESTION FIDÉLITÉ ===

    // Ajouter une récompense
    if ($action === 'add_reward') {
        header('Content-Type: application/json');
        try {
            $rewardId = LoyaltyRepository::addReward(SNACK_RESTAURANT_ID, [
                'name' => $_POST['reward_name'] ?? '',
                'description' => $_POST['reward_description'] ?? '',
                'points_required' => (int) ($_POST['points_required'] ?? 100),
                'reward_type' => $_POST['reward_type'] ?? 'discount_percent',
                'reward_value' => (float) ($_POST['reward_value'] ?? 10)
            ]);
            echo json_encode(['success' => true, 'reward_id' => $rewardId]);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
        exit;
    }

    // Supprimer une récompense
    if ($action === 'delete_reward') {
        header('Content-Type: application/json');
        $rewardId = (int) ($_POST['reward_id'] ?? 0);
        $deleted = LoyaltyRepository::deleteReward($rewardId);
        echo json_encode(['success' => $deleted]);
        exit;
    }

    // Modifier config fidélité
    if ($action === 'update_loyalty_config') {
        header('Content-Type: application/json');
        $enabled = ($_POST['loyalty_enabled'] ?? '1') === '1';
        $pointsPerEuro = (int) ($_POST['points_per_euro'] ?? 1);
        $updated = LoyaltyRepository::updateConfig(SNACK_RESTAURANT_ID, $enabled, $pointsPerEuro);
        echo json_encode(['success' => $updated]);
        exit;
    }

    // Ajouter des points manuellement à un client
    if ($action === 'add_loyalty_points') {
        header('Content-Type: application/json');
        $customerId = (int) ($_POST['customer_id'] ?? 0);
        $points = (int) ($_POST['points'] ?? 0);
        if ($customerId > 0 && $points != 0) {
            LoyaltyRepository::addPoints($customerId, SNACK_RESTAURANT_ID, $points, null, 'Ajout manuel admin');
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Données invalides']);
        }
        exit;
    }

    // Rechercher un client (AJAX)
    if ($action === 'search_customer') {
        header('Content-Type: application/json');
        $query = trim($_POST['query'] ?? '');
        if (strlen($query) >= 2) {
            $results = CustomerRepository::search(SNACK_RESTAURANT_ID, $query);
            echo json_encode(['success' => true, 'customers' => $results]);
        } else {
            echo json_encode(['success' => false, 'customers' => []]);
        }
        exit;
    }

    // Utiliser une récompense (échanger des points)
    if ($action === 'redeem_reward') {
        header('Content-Type: application/json');
        try {
            $customerId = (int) ($_POST['customer_id'] ?? 0);
            $rewardId = (int) ($_POST['reward_id'] ?? 0);

            if ($customerId <= 0 || $rewardId <= 0) {
                throw new Exception('Données invalides');
            }

            // Récupérer le client et la récompense
            $customer = CustomerRepository::getById($customerId);
            $rewards = LoyaltyRepository::getAllRewards(SNACK_RESTAURANT_ID);
            $reward = null;
            foreach ($rewards as $r) {
                if ($r['id'] == $rewardId) {
                    $reward = $r;
                    break;
                }
            }

            if (!$customer || !$reward) {
                throw new Exception('Client ou récompense non trouvé');
            }

            $customerPoints = (int) ($customer['loyalty_points'] ?? 0);
            $pointsRequired = (int) $reward['points_required'];

            if ($customerPoints < $pointsRequired) {
                throw new Exception('Points insuffisants (' . $customerPoints . '/' . $pointsRequired . ')');
            }

            // Déduire les points
            $success = LoyaltyRepository::redeemPoints($customerId, SNACK_RESTAURANT_ID, $pointsRequired, $reward['name']);

            if ($success) {
                $newPoints = $customerPoints - $pointsRequired;
                echo json_encode([
                    'success' => true,
                    'message' => 'Récompense "' . $reward['name'] . '" appliquée !',
                    'new_points' => $newPoints
                ]);
            } else {
                throw new Exception('Erreur lors de l\'échange');
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
        exit;
    }

    // Ajouter un client manuellement
    if ($action === 'add_customer') {
        header('Content-Type: application/json');
        try {
            $name = trim($_POST['customer_name'] ?? '');
            $phone = trim($_POST['customer_phone'] ?? '');

            if (empty($phone)) {
                throw new Exception("Le numéro de téléphone est requis");
            }

            $customerId = CustomerRepository::addCustomer(SNACK_RESTAURANT_ID, [
                'name' => $name ?: 'Client',
                'phone' => $phone
            ]);

            echo json_encode(['success' => true, 'customer_id' => $customerId]);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
        exit;
    }

    // Supprimer un client
    if ($action === 'delete_customer') {
        header('Content-Type: application/json');
        try {
            $customerId = (int) ($_POST['customer_id'] ?? 0);

            if ($customerId <= 0) {
                throw new Exception("ID client invalide");
            }

            $deleted = CustomerRepository::deleteCustomer($customerId, SNACK_RESTAURANT_ID);

            if ($deleted) {
                echo json_encode(['success' => true]);
            } else {
                throw new Exception("Impossible de supprimer ce client");
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
        exit;
    }

    // Changement de statut commande
    if ($_POST['action'] === 'change_status' && isset($_POST['order_id'], $_POST['new_status'])) {
        if ($useMySQL) {
            $order = OrderRepository::getByNumber(SNACK_RESTAURANT_ID, $_POST['order_id']);
            if ($order) {
                $oldStatus = $order['status'] ?? '';
                OrderRepository::updateStatus($order['id'], $_POST['new_status']);

                // === ATTRIBUTION AUTOMATIQUE DES POINTS FIDÉLITÉ ===
                // Quand une commande passe à "completed" pour la première fois
                if ($_POST['new_status'] === 'completed' && $oldStatus !== 'completed') {
                    $loyaltyConfig = LoyaltyRepository::getConfig(SNACK_RESTAURANT_ID);

                    if ($loyaltyConfig['enabled'] && !empty($order['customer_id'])) {
                        // 1. D'abord déduire les points si une récompense était utilisée
                        if (!empty($order['loyalty_reward_id']) && empty($order['loyalty_redeemed'])) {
                            OrderRepository::redeemLoyaltyPoints($order['id'], SNACK_RESTAURANT_ID);
                        }

                        // 2. Ensuite ajouter les points gagnés sur cette commande
                        $orderTotal = (float) ($order['total'] ?? 0);
                        $pointsPerEuro = (int) ($loyaltyConfig['points_per_euro'] ?? 1);
                        $pointsEarned = (int) floor($orderTotal * $pointsPerEuro);

                        if ($pointsEarned > 0) {
                            LoyaltyRepository::addPoints(
                                $order['customer_id'],
                                SNACK_RESTAURANT_ID,
                                $pointsEarned,
                                $order['id'],
                                'Commande #' . ($order['order_number'] ?? $order['id']) . ' - ' . number_format($orderTotal, 0) . ' DA'
                            );
                        }
                    }
                }
            }
        } else {
            foreach ($orders as &$order) {
                if ($order['id'] === $_POST['order_id']) {
                    $order['status'] = $_POST['new_status'];
                    if ($_POST['new_status'] === 'completed') {
                        $order['completed_at'] = date('Y-m-d H:i:s');
                    }
                    break;
                }
            }
            saveData('orders.json', $orders);
        }
        header('Location: index.php');
        exit;
    }

    // Archiver toutes les commandes
    if ($_POST['action'] === 'clear_orders') {
        if ($useMySQL) {
            OrderRepository::archiveAllCompleted(SNACK_RESTAURANT_ID);
        } else {
            $archivedOrders = array_merge($archivedOrders, $orders);
            saveData('orders-archive.json', $archivedOrders);
            saveData('orders.json', []);
        }
        header('Location: index.php');
        exit;
    }

       // Sauvegarder les réglages
    if ($_POST['action'] === 'save_settings') {
        // Vérifier quel formulaire a été soumis
        $isContactForm = isset($_POST['social_type']);
        $isHoursForm = isset($_POST['hours']);

        // Parser les réseaux sociaux dynamiques (seulement si formulaire contact soumis)
        if ($isContactForm) {
            $socialTypes = $_POST['social_type'] ?? [];
            $socialValues = $_POST['social_value'] ?? [];
            $socials = ['instagram' => '', 'facebook' => '', 'tiktok' => '', 'snapchat' => '', 'extra' => []];

            foreach ($socialTypes as $i => $type) {
                $value = trim($socialValues[$i] ?? '');
                if (empty($value)) continue;

                if (in_array($type, ['instagram', 'facebook', 'tiktok', 'snapchat']) && empty($socials[$type])) {
                    $socials[$type] = $value;
                } else {
                    $socials['extra'][] = ['type' => $type, 'value' => $value];
                }
            }

            // Parser les téléphones supplémentaires
            $extraPhones = array_filter(array_map('trim', $_POST['extra_phones'] ?? []));

            if ($useMySQL) {
                // Contact et social
                $settingsData = [];
                if (isset($_POST['phone'])) $settingsData['phone'] = $_POST['phone'];
                if (isset($_POST['whatsapp'])) $settingsData['whatsapp_number'] = $_POST['whatsapp'];
                $settingsData['instagram'] = $socials['instagram'];
                $settingsData['facebook'] = $socials['facebook'];
                $settingsData['tiktok'] = $socials['tiktok'];
                $settingsData['snapchat'] = $socials['snapchat'];
                $settingsData['extra_socials'] = json_encode($socials['extra']);
                $settingsData['extra_phones'] = json_encode($extraPhones);

                if (!empty($settingsData)) {
                    RestaurantRepository::updateSettings(SNACK_RESTAURANT_ID, $settingsData);
                }
            }

            // Mettre à jour restaurant.json - contact et social
            if (isset($_POST['phone'])) $restaurantSettings['contact']['phone'] = $_POST['phone'];
            if (isset($_POST['whatsapp'])) $restaurantSettings['contact']['whatsappOrdersNumber'] = $_POST['whatsapp'];
            $restaurantSettings['contact']['extra_phones'] = $extraPhones;
            $restaurantSettings['social']['instagram'] = $socials['instagram'];
            $restaurantSettings['social']['facebook'] = $socials['facebook'];
            $restaurantSettings['social']['tiktok'] = $socials['tiktok'];
            $restaurantSettings['social']['snapchat'] = $socials['snapchat'];
            $restaurantSettings['social']['extra'] = $socials['extra'];
        }

        // Traitement des horaires (formulaire horaires)
        if ($isHoursForm) {
            if ($useMySQL) {
                $hours = [];
                foreach ($_POST['hours'] as $i => $h) {
                    $hours[] = [
                        'opens' => $h['opens'] ?? '18:30',
                        'closes' => $h['closes'] ?? '23:30'
                    ];
                }
                RestaurantRepository::updateOpeningHours(SNACK_RESTAURANT_ID, $hours);
            }

            // Mettre à jour restaurant.json - horaires
            $restaurantSettings['openingHours'] = [];
            $days = ['lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi', 'dimanche'];
            foreach ($days as $i => $day) {
                $dayData = ['day' => $day];
                // Nouveau format avec slots multiples
                if (isset($_POST['hours'][$i]['slots'])) {
                    $slots = [];
                    foreach ($_POST['hours'][$i]['slots'] as $slot) {
                        if (!empty($slot['opens']) && !empty($slot['closes'])) {
                            $slots[] = [
                                'opens' => $slot['opens'],
                                'closes' => $slot['closes']
                            ];
                        }
                    }
                    $dayData['slots'] = $slots;
                    // Garder compatibilité avec ancien format (premier créneau)
                    if (!empty($slots)) {
                        $dayData['opens'] = $slots[0]['opens'];
                        $dayData['closes'] = $slots[0]['closes'];
                    }
                } else {
                    // Ancien format
                    $dayData['opens'] = $_POST['hours'][$i]['opens'] ?? '18:30';
                    $dayData['closes'] = $_POST['hours'][$i]['closes'] ?? '23:30';
                }
                $restaurantSettings['openingHours'][] = $dayData;
            }
        }

        // Sauvegarder restaurant.json
        file_put_contents(__DIR__ . '/../config/restaurant.json', json_encode($restaurantSettings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

        header('Location: index.php#settings');
        exit;
    }

    // Sauvegarder FAQ
    if ($_POST['action'] === 'save_faq') {
        $faqItemsNew = [];
        if (isset($_POST['faq_q']) && isset($_POST['faq_a'])) {
            foreach ($_POST['faq_q'] as $i => $q) {
                if (trim($q) !== '' && trim($_POST['faq_a'][$i]) !== '') {
                    $faqItemsNew[] = ['question' => trim($q), 'answer' => trim($_POST['faq_a'][$i])];
                }
            }
        }

        if ($useMySQL) {
            RestaurantRepository::updateFaq(SNACK_RESTAURANT_ID, $faqItemsNew);
        }
        // Toujours mettre à jour restaurant.json pour le site public
        $restaurantSettings['faq']['items'] = $faqItemsNew;
        file_put_contents(__DIR__ . '/../config/restaurant.json', json_encode($restaurantSettings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

        header('Location: index.php#settings');
        exit;
    }

    // Sauvegarder configuration WhatsApp Business API
    if ($_POST['action'] === 'save_whatsapp_config') {
        if ($useMySQL) {
            RestaurantRepository::updateWhatsAppConfig(SNACK_RESTAURANT_ID, [
                'token' => $_POST['whatsapp_token'] ?? '',
                'phoneNumberId' => $_POST['whatsapp_phone_id'] ?? '',
                'businessAccountId' => $_POST['whatsapp_business_id'] ?? ''
            ]);
        } else {
            if (!isset($restaurantSettings['whatsapp'])) {
                $restaurantSettings['whatsapp'] = [];
            }
            $newToken = trim($_POST['whatsapp_token'] ?? '');
            if (!empty($newToken)) {
                $restaurantSettings['whatsapp']['token'] = $newToken;
            }
            $restaurantSettings['whatsapp']['phoneNumberId'] = trim($_POST['whatsapp_phone_id'] ?? '');
            $restaurantSettings['whatsapp']['businessAccountId'] = trim($_POST['whatsapp_business_id'] ?? '');
            $restaurantSettings['whatsapp']['configured'] = !empty($restaurantSettings['whatsapp']['token']);

            file_put_contents(__DIR__ . '/../config/restaurant.json', json_encode($restaurantSettings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        }
        header('Location: index.php#settings');
        exit;
    }
}

// ============================================
// EXPORT CSV
// ============================================

if (isset($_GET['export'])) {
    header('Content-Type: text/csv; charset=utf-8');

    if ($_GET['export'] === 'customers') {
        header('Content-Disposition: attachment; filename=clients_' . date('Y-m-d') . '.csv');

        if ($useMySQL) {
            echo CustomerRepository::exportCSV(SNACK_RESTAURANT_ID);
        } else {
            $customers = loadData('customers.json') ?? [];
            echo "\xEF\xBB\xBF";
            echo "Nom,Téléphone,Commandes,Total dépensé\n";
            foreach ($customers as $c) {
                echo '"' . ($c['name'] ?? '') . '","' . ($c['phone'] ?? '') . '",' . ($c['orders_count'] ?? 0) . ',' . ($c['total_spent'] ?? 0) . "\n";
            }
        }
        exit;
    }

    if ($_GET['export'] === 'stats') {
        $period = $_GET['period'] ?? 'month';
        header('Content-Disposition: attachment; filename=stats_' . $period . '_' . date('Y-m-d') . '.csv');
        if ($useMySQL) {
            echo OrderRepository::exportStatsCSV(SNACK_RESTAURANT_ID, $period);
        }
        exit;
    }



    if ($_GET['export'] === 'archives') {
        $filterMonth = $_GET['month'] ?? '';
        $filteredOrders = $archivedOrders;

        // Filtrer par mois si spécifié
        if ($filterMonth) {
            $filteredOrders = array_filter($archivedOrders, function($o) use ($filterMonth) {
                $orderMonth = date('Y-m', strtotime($o['created_at'] ?? 'now'));
                return $orderMonth === $filterMonth;
            });
        }

        $filename = $filterMonth
            ? 'commandes_' . $filterMonth . '.csv'
            : 'commandes_archivees_' . date('Y-m-d') . '.csv';

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $filename);
        echo "\xEF\xBB\xBF";
        echo "ID,Date,Heure,Client,Téléphone,Total,Statut,Produits\n";
        foreach ($filteredOrders as $o) {
            $items = array_map(fn($i) => ($i['quantity'] ?? 1) . 'x ' . ($i['name'] ?? $i['product_name'] ?? ''), $o['items'] ?? []);
            $dateTime = $o['created_at'] ?? '';
            $date = date('Y-m-d', strtotime($dateTime));
            $time = date('H:i', strtotime($dateTime));
            echo '"' . ($o['id'] ?? $o['order_number'] ?? '') . '","' . $date . '","' . $time . '","' . ($o['customer_name'] ?? '') . '","' . ($o['customer_phone'] ?? '') . '",' . ($o['total'] ?? 0) . ',"' . ($o['status'] ?? '') . '","' . implode('; ', $items) . "\"\n";
        }
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - <?php echo htmlspecialchars($restaurantName); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;
            background: linear-gradient(135deg, #0f0f1a 0%, #1a1a2e 50%, #0f1525 100%);
            background-attachment: fixed;
            color: #fff;
            padding-bottom: 90px;
            min-height: 100vh;
        }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .header {
            background: linear-gradient(135deg, rgba(255,255,255,0.08) 0%, rgba(255,255,255,0.03) 100%);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            padding: 16px 20px;
            margin-bottom: 20px;
            border-radius: 16px;
            border: 1px solid rgba(255,255,255,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.3);
        }
        .header h1 { font-size: 20px; font-weight: 700; }
        .btn {
            background: linear-gradient(135deg, <?php echo $primaryColor; ?> 0%, <?php echo $primaryColor; ?>dd 100%);
            color: white;
            padding: 10px 18px;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.2s ease;
            box-shadow: 0 4px 15px <?php echo $primaryColor; ?>40;
        }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 6px 20px <?php echo $primaryColor; ?>50; }
        .btn:active { transform: translateY(0); }
        .btn-sm { padding: 8px 14px; font-size: 12px; border-radius: 10px; }
        .btn-green { background: linear-gradient(135deg, #10b981 0%, #059669 100%); box-shadow: 0 4px 15px rgba(16,185,129,0.3); }
        .btn-gray { background: linear-gradient(135deg, #4b5563 0%, #374151 100%); box-shadow: 0 4px 15px rgba(75,85,99,0.3); }
        .btn-whatsapp { background: linear-gradient(135deg, #25D366 0%, #128C7E 100%); box-shadow: 0 4px 15px rgba(37,211,102,0.3); }
        .card {
            background: linear-gradient(135deg, rgba(255,255,255,0.06) 0%, rgba(255,255,255,0.02) 100%);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            padding: 20px;
            margin-bottom: 15px;
            border-radius: 16px;
            border: 1px solid rgba(255,255,255,0.08);
            box-shadow: 0 4px 24px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
        }
        .card:hover { border-color: rgba(255,255,255,0.12); }
        .stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 20px; }
        .stat-card {
            background: linear-gradient(135deg, rgba(255,255,255,0.08) 0%, rgba(255,255,255,0.03) 100%);
            backdrop-filter: blur(10px);
            padding: 18px;
            text-align: center;
            border-radius: 16px;
            border: 1px solid rgba(255,255,255,0.08);
            transition: all 0.3s ease;
        }
        .stat-card:hover { transform: translateY(-3px); box-shadow: 0 8px 25px rgba(0,0,0,0.3); }
        .stat-number { font-size: 28px; font-weight: 700; margin-top: 6px; background: linear-gradient(135deg, #fff 0%, #e0e0e0 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: linear-gradient(180deg, rgba(20,20,35,0.95) 0%, rgba(15,15,25,0.98) 100%);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-top: 1px solid rgba(255,255,255,0.1);
            display: flex;
            justify-content: space-around;
            padding: 8px 8px calc(8px + env(safe-area-inset-bottom));
            z-index: 1000;
        }
        .nav-btn {
            flex: 1;
            text-align: center;
            padding: 8px 4px;
            background: none;
            border: none;
            color: #666;
            cursor: pointer;
            font-size: 10px;
            border-radius: 12px;
            transition: all 0.2s ease;
        }
        .nav-btn:hover { background: rgba(255,255,255,0.05); }
        .nav-btn.active { color: <?php echo $primaryColor; ?>; background: <?php echo $primaryColor; ?>15; }
        .nav-btn i { display: block; font-size: 20px; margin-bottom: 4px; }
        .section { display: none; animation: fadeIn 0.3s ease; }
        .section.active { display: block; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; margin-bottom: 6px; color: #9ca3af; font-size: 13px; font-weight: 500; }
        .form-group input, .form-group textarea, .form-group select {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 12px;
            background: rgba(0,0,0,0.3);
            color: white;
            font-size: 15px;
            transition: all 0.2s ease;
        }
        .form-group input:focus, .form-group textarea:focus, .form-group select:focus {
            outline: none;
            border-color: <?php echo $primaryColor; ?>;
            box-shadow: 0 0 0 3px <?php echo $primaryColor; ?>30;
        }
        .form-group textarea { min-height: 80px; resize: vertical; }
        .hours-grid { display: grid; grid-template-columns: 100px 1fr 1fr; gap: 10px; align-items: center; margin-bottom: 10px; }
        .hours-grid span { color: #9ca3af; font-weight: 500; }
        .checkbox-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px;
            background: rgba(0,0,0,0.2);
            border-radius: 12px;
            margin-bottom: 8px;
            cursor: pointer;
            border: 1px solid transparent;
            transition: all 0.2s ease;
        }
        .checkbox-item:hover { background: rgba(255,255,255,0.05); border-color: rgba(255,255,255,0.1); }
        .checkbox-item input { width: 20px; height: 20px; accent-color: <?php echo $primaryColor; ?>; }
        /* ===== RESPONSIVE MOBILE ===== */
        @media (max-width: 768px) {
            .stats { grid-template-columns: repeat(2, 1fr); }
            .hours-grid { grid-template-columns: 1fr; gap: 8px; }
            .hours-grid span { font-weight: 600; margin-bottom: 4px; }
        }

        @media (max-width: 480px) {
            body { padding-bottom: calc(75px + env(safe-area-inset-bottom)); }
            .container { padding: 12px; }

            /* Header mobile - style app */
            .header {
                padding: 14px;
                flex-direction: row;
                align-items: center;
                gap: 10px;
                margin: 0 -12px 16px;
                border-radius: 0 0 20px 20px;
                position: sticky;
                top: 0;
                z-index: 100;
            }
            .header h1 { font-size: 17px; }
            .header > div:last-child { margin-left: auto; }

            /* Boutons tactiles */
            .btn {
                padding: 12px 16px;
                font-size: 14px;
                border-radius: 14px;
                min-height: 44px;
            }
            .btn-sm { padding: 10px 14px; font-size: 12px; min-height: 40px; }

            /* Stats - style moderne */
            .stats { grid-template-columns: 1fr 1fr; gap: 10px; }
            .stat-card {
                padding: 16px 12px;
                border-radius: 18px;
            }
            .stat-card > div:first-child { font-size: 11px; opacity: 0.8; }
            .stat-number { font-size: 24px; }

            /* Cards - style fluide */
            .card {
                padding: 16px;
                margin-bottom: 12px;
                border-radius: 18px;
            }

            /* Navigation basse - style iOS/Android */
            .bottom-nav {
                padding: 6px 12px calc(6px + env(safe-area-inset-bottom));
                gap: 4px;
            }
            .nav-btn {
                padding: 8px 6px;
                font-size: 9px;
                border-radius: 14px;
                min-width: 54px;
            }
            .nav-btn i { font-size: 18px; margin-bottom: 3px; }

            /* Commandes - layout mobile */
            .card > div:first-child { flex-direction: column; gap: 10px; }
            .card > div:first-child > div:last-child { text-align: left !important; }

            /* Filtres - scroll horizontal fluide */
            .customer-filters-wrap {
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
                scroll-snap-type: x mandatory;
                padding-bottom: 8px;
                margin: 0 -12px;
                padding: 0 12px 10px;
                scrollbar-width: none;
            }
            .customer-filters-wrap::-webkit-scrollbar { display: none; }
            .customer-filters-wrap > div {
                display: flex;
                gap: 8px;
                min-width: max-content;
            }
            .customer-filters-wrap .btn { scroll-snap-align: start; }

            /* Formulaires tactiles */
            .form-group { margin-bottom: 14px; }
            .form-group label { font-size: 12px; margin-bottom: 8px; }
            .form-group input, .form-group textarea, .form-group select {
                padding: 14px 16px;
                font-size: 16px;
                border-radius: 14px;
                min-height: 48px;
            }

            /* Horaires - style card */
            .hours-grid {
                background: rgba(0,0,0,0.25);
                padding: 14px;
                border-radius: 14px;
                margin-bottom: 10px;
                margin-bottom: 10px;
            }
            .hours-grid input[type="time"] {
                width: 100%;
                padding: 10px;
            }

            /* Archives */
            .card > div[style*="border-bottom"] {
                flex-wrap: wrap;
                gap: 8px;
            }

            /* Section titres */
            h2 { font-size: 18px; }
            h3 { font-size: 15px; }

            /* Toggle restaurant */
            #restaurant-status-toggle h3 { font-size: 14px; }
            #status-indicator { font-size: 24px !important; }
        }

        /* Très petits écrans */
        @media (max-width: 360px) {
            .container { padding: 8px; }
            .btn { padding: 8px 10px; font-size: 12px; }
            .stat-number { font-size: 18px; }
            .nav-btn i { font-size: 14px; }
            .nav-btn div { font-size: 8px; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div>
                <h1><?php echo htmlspecialchars($restaurantName); ?></h1>
                <p style="color: #9ca3af; font-size: 12px;">Administration</p>
            </div>
            <div style="display: flex; gap: 10px;">
                <a href="index.php" class="btn btn-sm"><i class="fas fa-sync-alt"></i></a>
                <a href="logout.php" class="btn btn-sm btn-gray"><i class="fas fa-sign-out-alt"></i></a>
            </div>
        </div>

        <!-- Toggle Restaurant -->
        <div id="restaurant-status-toggle" class="card" style="border: 2px solid #444; cursor: pointer;" onclick="toggleRestaurantStatus()">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <h3 style="font-size: 16px;"><i class="fas fa-power-off"></i> <span id="status-text">Chargement...</span></h3>
                    <p style="color: #9ca3af; font-size: 12px;" id="status-subtitle">Cliquez pour changer</p>
                </div>
                <div id="status-indicator" style="font-size: 28px;"><i class="fas fa-circle-notch fa-spin"></i></div>
            </div>
        </div>

        <!-- COMMANDES -->
        <div id="section-orders" class="section active">
            <!-- Header -->
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
                <h2><i class="fas fa-receipt" style="color: <?php echo $primaryColor; ?>;"></i> Commandes (<?php echo count($orders); ?>)</h2>
                <?php if (!empty($orders)): ?>
                <form method="POST" style="margin: 0;">
                    <input type="hidden" name="action" value="clear_orders">
                    <button type="submit" onclick="return confirm('Archiver toutes les commandes terminées ?')" class="btn btn-sm btn-gray"><i class="fas fa-archive"></i> Archiver tout</button>
                </form>
                <?php endif; ?>
            </div>

            <!-- Stats -->
            <div class="stats" style="margin-bottom: 20px;">
                <div class="stat-card" style="border-left: 4px solid #f59e0b;">
                    <div style="color: #f59e0b;"><i class="fas fa-clock"></i></div>
                    <div class="stat-number" style="color: #f59e0b;"><?php echo $stats['pending']; ?></div>
                    <div style="color: #9ca3af; font-size: 11px;">En attente</div>
                </div>
                <div class="stat-card" style="border-left: 4px solid #10b981;">
                    <div style="color: #10b981;"><i class="fas fa-check-circle"></i></div>
                    <div class="stat-number" style="color: #10b981;"><?php echo $stats['completed']; ?></div>
                    <div style="color: #9ca3af; font-size: 11px;">Terminées</div>
                </div>
                <div class="stat-card" style="border-left: 4px solid <?php echo $primaryColor; ?>;">
                    <div style="color: <?php echo $primaryColor; ?>;"><i class="fas fa-calendar-day"></i></div>
                    <div class="stat-number" style="color: <?php echo $primaryColor; ?>;"><?php echo $stats['today']; ?></div>
                    <div style="color: #9ca3af; font-size: 11px;">Aujourd'hui</div>
                </div>
            </div>

            <!-- Liste des commandes -->
            <?php if (empty($orders)): ?>
                <div class="card" style="text-align: center; padding: 60px;">
                    <i class="fas fa-inbox" style="font-size: 48px; color: #555; margin-bottom: 15px;"></i>
                    <p style="color: #9ca3af; font-size: 16px;">Aucune commande en cours</p>
                    <p style="color: #6b7280; font-size: 13px;">Les nouvelles commandes apparaîtront ici</p>
                </div>
            <?php else: ?>
                <div style="display: grid; gap: 15px;">
                <?php foreach ($orders as $order):
                    $isCompleted = ($order['status'] ?? '') === 'completed';
                    $statusColor = $isCompleted ? '#10b981' : '#f59e0b';
                    $statusIcon = $isCompleted ? 'check-circle' : 'clock';
                    $statusText = $isCompleted ? 'Terminée' : 'En attente';
                ?>
                <div class="card" style="border-left: 4px solid <?php echo $statusColor; ?>; padding: 15px;">
                    <!-- En-tête commande -->
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 12px;">
                        <div style="display: flex; align-items: center; gap: 12px;">
                            <div style="width: 45px; height: 45px; border-radius: 50%; background: linear-gradient(135deg, <?php echo $primaryColor; ?>, #d97706); display: flex; align-items: center; justify-content: center; font-size: 18px; font-weight: bold; color: white;">
                                <?php echo strtoupper(substr($order['customer_name'] ?? 'C', 0, 1)); ?>
                            </div>
                            <div>
                                <strong style="font-size: 15px; display: block;"><?php echo htmlspecialchars($order['customer_name'] ?? 'Client'); ?></strong>
                                <span style="color: #9ca3af; font-size: 12px;"><i class="fas fa-phone"></i> <?php echo htmlspecialchars($order['customer_phone'] ?? 'N/A'); ?></span>
                            </div>
                        </div>
                        <div style="text-align: right;">
                            <div style="font-size: 18px; font-weight: bold; color: <?php echo $primaryColor; ?>;"><?php echo number_format($order['total'] ?? 0, 0); ?> DA</div>
                            <span style="color: #6b7280; font-size: 11px;">#<?php echo htmlspecialchars($order['id']); ?></span>
                        </div>
                    </div>

                    <!-- Statut et date -->
                    <div style="display: flex; gap: 10px; margin-bottom: 12px;">
                        <span style="background: <?php echo $statusColor; ?>22; color: <?php echo $statusColor; ?>; padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: 600;">
                            <i class="fas fa-<?php echo $statusIcon; ?>"></i> <?php echo $statusText; ?>
                        </span>
                        <span style="background: #374151; color: #9ca3af; padding: 4px 10px; border-radius: 20px; font-size: 11px;">
                            <i class="fas fa-clock"></i> <?php echo date('d/m H:i', strtotime($order['created_at'])); ?>
                        </span>
                    </div>

                    <!-- Articles -->
                    <div style="background: #1e293b; padding: 12px; border-radius: 8px; margin-bottom: 12px;">
                        <?php foreach ($order['items'] ?? [] as $i => $item): ?>
                            <div style="display: flex; justify-content: space-between; padding: 4px 0; <?php echo $i > 0 ? 'border-top: 1px solid #374151; margin-top: 4px;' : ''; ?>">
                                <span style="color: #d1d5db; font-size: 13px;">
                                    <strong style="color: <?php echo $primaryColor; ?>;"><?php echo $item['quantity'] ?? 1; ?>x</strong>
                                    <?php echo htmlspecialchars($item['name']); ?>
                                    <?php if (!empty($item['supplements'])): ?>
                                        <span style="color: #6b7280; font-size: 11px;">(+<?php echo implode(', ', array_column($item['supplements'], 'name')); ?>)</span>
                                    <?php endif; ?>
                                </span>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <?php if (!empty($order['notes'])): ?>
                    <div style="background: #fef3c7; color: #92400e; padding: 10px; border-radius: 8px; margin-bottom: 12px; font-size: 12px;">
                        <i class="fas fa-sticky-note"></i> <strong>Note:</strong> <?php echo htmlspecialchars($order['notes']); ?>
                    </div>
                    <?php endif; ?>

                    <?php if (!empty($order['loyalty_reward_id'])): ?>
                    <?php
                        $loyaltyReward = $order['loyalty_reward'] ?? Database::fetchOne("SELECT * FROM loyalty_rewards WHERE id = ?", [$order['loyalty_reward_id']]);
                        $isRedeemed = !empty($order['loyalty_redeemed']);
                    ?>
                    <div style="background: <?= $isRedeemed ? 'rgba(16,185,129,0.15)' : 'rgba(245,158,11,0.15)' ?>; border: 1px solid <?= $isRedeemed ? '#10b981' : '#f59e0b' ?>; padding: 10px; border-radius: 8px; margin-bottom: 12px; font-size: 12px;">
                        <i class="fas fa-gift" style="color: <?= $isRedeemed ? '#10b981' : '#f59e0b' ?>;"></i>
                        <strong style="color: <?= $isRedeemed ? '#10b981' : '#f59e0b' ?>;">FIDÉLITÉ:</strong>
                        <?= htmlspecialchars($loyaltyReward['name'] ?? 'Récompense') ?>
                        <span style="color: #6b7280;">(-<?= $order['loyalty_points_used'] ?? $loyaltyReward['points_required'] ?? 0 ?> pts)</span>
                        <?php if ($isRedeemed): ?>
                            <span style="color: #10b981; margin-left: 5px;"><i class="fas fa-check"></i> Déduit</span>
                        <?php else: ?>
                            <span style="color: #f59e0b; margin-left: 5px;"><i class="fas fa-clock"></i> À déduire</span>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                    <!-- Actions -->
                    <div style="display: flex; gap: 10px;">
                        <?php if (!$isCompleted): ?>
                        <form method="POST" style="flex: 1;">
                            <input type="hidden" name="action" value="change_status">
                            <input type="hidden" name="order_id" value="<?php echo htmlspecialchars($order['id']); ?>">
                            <button type="submit" name="new_status" value="completed" class="btn btn-green" style="width: 100%;"><i class="fas fa-check"></i> Marquer terminée</button>
                        </form>
                        <?php else: ?>
                        <div style="flex: 1; text-align: center; padding: 10px; background: rgba(16,185,129,0.1); border-radius: 8px; color: #10b981; font-weight: 600;">
                            <i class="fas fa-check-circle"></i> Commande terminée
                        </div>
                        <?php endif; ?>
                        <a href="https://wa.me/<?php echo preg_replace('/[^0-9]/', '', $order['customer_phone'] ?? ''); ?>?text=<?php echo urlencode('Bonjour ! Votre commande #' . $order['id'] . ' est prête !'); ?>" target="_blank" class="btn btn-whatsapp" style="padding: 10px 15px;"><i class="fab fa-whatsapp"></i></a>
                    </div>
                </div>
                <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- CLIENTS -->
        <div id="section-customers" class="section">
            <?php
            // Calculer les stats clients
            $totalCustomers = count($customers);
            $newCustomers = 0;
            $regularCustomers = 0;
            $vipCustomers = 0;

            foreach ($customers as $c) {
                $ordersCount = $c['orders_count'] ?? 0;
                $totalSpent = $c['total_spent'] ?? 0;

                if ($ordersCount <= 1) {
                    $newCustomers++;
                } elseif ($totalSpent >= 200 || $ordersCount >= 10) {
                    $vipCustomers++;
                } else {
                    $regularCustomers++;
                }
            }
            ?>

            <!-- Header avec boutons -->
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
                <h2><i class="fas fa-users"></i> Clients (<?= $totalCustomers ?>)</h2>
                <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                    <a href="?export=customers" class="btn btn-sm btn-gray"><i class="fas fa-download"></i> CSV</a>
                    <button onclick="toggleBroadcastPanel()" class="btn btn-sm btn-whatsapp"><i class="fab fa-whatsapp"></i> Diffusion</button>
                    <button onclick="openAddCustomerModal()" class="btn btn-sm" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);"><i class="fas fa-plus"></i> Ajouter</button>
                </div>
            </div>

            <!-- Stats Clients -->
            <div class="stats" style="margin-bottom: 20px;">
                <div class="stat-card" style="border-left: 4px solid #3b82f6;">
                    <div style="color: #3b82f6;"><i class="fas fa-seedling"></i></div>
                    <div class="stat-number" style="color: #3b82f6;"><?= $newCustomers ?></div>
                    <div style="color: #9ca3af; font-size: 11px;">Nouveaux</div>
                </div>
                <div class="stat-card" style="border-left: 4px solid #10b981;">
                    <div style="color: #10b981;"><i class="fas fa-star"></i></div>
                    <div class="stat-number" style="color: #10b981;"><?= $regularCustomers ?></div>
                    <div style="color: #9ca3af; font-size: 11px;">Réguliers</div>
                </div>
                <div class="stat-card" style="border-left: 4px solid #f59e0b;">
                    <div style="color: #f59e0b;"><i class="fas fa-crown"></i></div>
                    <div class="stat-number" style="color: #f59e0b;"><?= $vipCustomers ?></div>
                    <div style="color: #9ca3af; font-size: 11px;">VIP</div>
                </div>
            </div>

            <!-- Filtres rapides -->
            <div class="customer-filters-wrap" style="margin-bottom: 15px;">
                <div style="display: flex; gap: 8px; flex-wrap: nowrap;">
                    <button onclick="filterCustomers('all')" class="btn btn-sm customer-filter active" data-filter="all" style="white-space: nowrap;"><i class="fas fa-users"></i> Tous</button>
                    <button onclick="filterCustomers('vip')" class="btn btn-sm customer-filter" data-filter="vip" style="background: rgba(245,158,11,.2); border-color: #f59e0b; white-space: nowrap;"><i class="fas fa-crown"></i> VIP</button>
                    <button onclick="filterCustomers('regular')" class="btn btn-sm customer-filter" data-filter="regular" style="background: rgba(16,185,129,.2); border-color: #10b981; white-space: nowrap;"><i class="fas fa-star"></i> Réguliers</button>
                    <button onclick="filterCustomers('new')" class="btn btn-sm customer-filter" data-filter="new" style="background: rgba(59,130,246,.2); border-color: #3b82f6; white-space: nowrap;"><i class="fas fa-seedling"></i> Nouveaux</button>
                </div>
            </div>

            <!-- Panel WhatsApp groupé (Diffusion) -->
            <div class="card" id="whatsapp-panel" style="display: none; margin-bottom: 15px; border: 2px solid #25D366;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                    <h4 style="color: #25D366; margin: 0;"><i class="fab fa-whatsapp"></i> Diffusion WhatsApp</h4>
                    <button onclick="toggleBroadcastPanel()" class="btn btn-sm btn-gray"><i class="fas fa-times"></i></button>
                </div>
                <div class="form-group">
                    <label>Message promotionnel</label>
                    <textarea id="wa-message" rows="4" placeholder="Ex: Bonjour ! Profitez de -20% sur tous les burgers ce weekend avec le code BURGER20 ! À très vite chez nous !"></textarea>
                </div>
                <div style="background: #1e293b; padding: 12px; border-radius: 8px; margin-bottom: 15px;">
                    <p style="color: #9ca3af; font-size: 12px; margin: 0;">
                        <i class="fas fa-info-circle"></i> Cochez les clients ci-dessous, puis cliquez sur "Envoyer". WhatsApp s'ouvrira pour chaque client sélectionné.
                    </p>
                </div>
                <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                    <button onclick="selectAllCustomers()" class="btn btn-sm btn-gray"><i class="fas fa-check-double"></i> Tout sélectionner</button>
                    <button onclick="deselectAllCustomers()" class="btn btn-sm btn-gray"><i class="fas fa-times"></i> Tout désélectionner</button>
                    <button onclick="openWhatsAppLinks()" class="btn btn-whatsapp"><i class="fab fa-whatsapp"></i> Envoyer (<span id="selected-count">0</span> sélectionnés)</button>
                </div>
            </div>

            <!-- Barre de recherche -->
            <div style="margin-bottom: 15px;">
                <input type="text" id="customerSearch" placeholder="🔍 Rechercher par nom, téléphone ou code fidélité..."
                       onkeyup="searchCustomers()"
                       style="width: 100%; padding: 12px 16px; background: #1e293b; border: 1px solid #374151; border-radius: 10px; color: white; font-size: 14px;">
            </div>

            <!-- Tableau des clients -->
            <div class="card" style="padding: 0; overflow: hidden;">
                <?php if (empty($customers)): ?>
                    <div style="text-align: center; padding: 60px; color: #666;">
                        <div style="font-size: 4em; margin-bottom: 20px;"><i class="fas fa-users" style="color: #555;"></i></div>
                        <p style="font-size: 1.2em; color: #9ca3af;">Aucun client enregistré</p>
                        <p style="color: #6b7280;">Les clients apparaîtront ici après leur première commande</p>
                    </div>
                <?php else: ?>
                <div style="overflow-x: auto;">
                    <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
                        <thead>
                            <tr style="background: #1e293b; text-align: left;">
                                <th style="padding: 12px 15px; font-weight: 600; color: #9ca3af; white-space: nowrap;">
                                    <input type="checkbox" id="selectAllCheckbox" onchange="toggleAllCustomers(this)" style="width: 16px; height: 16px; display: none;" class="broadcast-cb">
                                </th>
                                <th style="padding: 12px 15px; font-weight: 600; color: #9ca3af;">Client</th>
                                <th style="padding: 12px 15px; font-weight: 600; color: #9ca3af;">Téléphone</th>
                                <th style="padding: 12px 15px; font-weight: 600; color: #9ca3af;">Code Fidélité</th>
                                <th style="padding: 12px 15px; font-weight: 600; color: #9ca3af; text-align: center;">Cmd</th>
                                <th style="padding: 12px 15px; font-weight: 600; color: #9ca3af; text-align: center;">Dépensé</th>
                                <th style="padding: 12px 15px; font-weight: 600; color: #9ca3af; text-align: center;">Points</th>
                                <th style="padding: 12px 15px; font-weight: 600; color: #9ca3af;">Statut</th>
                                <th style="padding: 12px 15px; font-weight: 600; color: #9ca3af; text-align: center;">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="customersTableBody">
                            <?php foreach ($customers as $customer):
                                $ordersCount = $customer['orders_count'] ?? 0;
                                $totalSpent = $customer['total_spent'] ?? 0;
                                $loyaltyPoints = $customer['loyalty_points'] ?? 0;

                                // Déterminer la catégorie
                                if ($ordersCount <= 1) {
                                    $category = 'new';
                                    $badge = '<span style="background: #3b82f6; color: white; padding: 3px 8px; border-radius: 10px; font-size: 10px; white-space: nowrap;"><i class="fas fa-seedling"></i> Nouveau</span>';
                                    $avatarBg = '#3b82f6';
                                } elseif ($totalSpent >= 200 || $ordersCount >= 10) {
                                    $category = 'vip';
                                    $badge = '<span style="background: #f59e0b; color: white; padding: 3px 8px; border-radius: 10px; font-size: 10px; white-space: nowrap;"><i class="fas fa-crown"></i> VIP</span>';
                                    $avatarBg = '#f59e0b';
                                } else {
                                    $category = 'regular';
                                    $badge = '<span style="background: #10b981; color: white; padding: 3px 8px; border-radius: 10px; font-size: 10px; white-space: nowrap;"><i class="fas fa-star"></i> Régulier</span>';
                                    $avatarBg = '#10b981';
                                }
                            ?>
                            <tr class="customer-row" data-category="<?= $category ?>" data-search="<?= strtolower(($customer['name'] ?? '') . ' ' . ($customer['phone'] ?? '') . ' ' . ($customer['loyalty_code'] ?? '')) ?>" style="border-bottom: 1px solid #2d3748; transition: background 0.2s;" onmouseover="this.style.background='rgba(255,255,255,0.03)'" onmouseout="this.style.background='transparent'">
                                <td style="padding: 10px 15px;">
                                    <input type="checkbox" class="customer-checkbox broadcast-cb" value="<?= htmlspecialchars($customer['phone'] ?? '') ?>" data-customer-id="<?= $customer['id'] ?>" onchange="updateSelectedCount()" style="width: 16px; height: 16px; display: none;">
                                </td>
                                <td style="padding: 10px 15px;">
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <div style="width: 32px; height: 32px; border-radius: 50%; background: <?= $avatarBg ?>; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: bold; color: white; flex-shrink: 0;">
                                            <?= strtoupper(substr($customer['name'] ?? 'C', 0, 1)) ?>
                                        </div>
                                        <span style="font-weight: 500;"><?= htmlspecialchars($customer['name'] ?? 'Client') ?></span>
                                    </div>
                                </td>
                                <td style="padding: 10px 15px; color: #9ca3af;"><?= htmlspecialchars($customer['phone'] ?? 'N/A') ?></td>
                                <td style="padding: 10px 15px;">
                                    <?php if (!empty($customer['loyalty_code'])): ?>
                                    <span style="color: #f59e0b; font-weight: 600; font-size: 11px;"><?= htmlspecialchars($customer['loyalty_code']) ?></span>
                                    <?php else: ?>
                                    <span style="color: #4b5563;">—</span>
                                    <?php endif; ?>
                                </td>
                                <td style="padding: 10px 15px; text-align: center; font-weight: 600; color: <?= $primaryColor ?>;"><?= $ordersCount ?></td>
                                <td style="padding: 10px 15px; text-align: center; font-weight: 600; color: #10b981;"><?= number_format($totalSpent, 0) ?> DA</td>
                                <td style="padding: 10px 15px; text-align: center; font-weight: 600; color: #f59e0b;"><?= $loyaltyPoints ?></td>
                                <td style="padding: 10px 15px;"><?= $badge ?></td>
                                <td style="padding: 10px 15px;">
                                    <div style="display: flex; gap: 6px; justify-content: center;">
                                        <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $customer['phone'] ?? '') ?>" target="_blank" class="btn btn-sm btn-whatsapp" style="padding: 6px 10px;" title="WhatsApp"><i class="fab fa-whatsapp"></i></a>
                                        <button onclick="openAddPointsModal(<?= $customer['id'] ?>, '<?= htmlspecialchars($customer['name'] ?? 'Client', ENT_QUOTES) ?>')" class="btn btn-sm" style="padding: 6px 10px; background: #f59e0b;" title="Ajouter points"><i class="fas fa-plus"></i></button>
                                        <button onclick="deleteCustomer(<?= $customer['id'] ?>, '<?= htmlspecialchars($customer['name'] ?? 'Client', ENT_QUOTES) ?>')" class="btn btn-sm" style="padding: 6px 10px; background: #dc2626;" title="Supprimer"><i class="fas fa-trash"></i></button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <!-- FIN CLIENTS -->

<!-- Modal Ajouter Client -->
<div id="addCustomerModal" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.7); z-index: 10000; align-items: center; justify-content: center;">
    <div style="background: white; border-radius: 20px; padding: 30px; max-width: 400px; width: 90%; box-shadow: 0 20px 60px rgba(0,0,0,0.3);">
        <h3 style="margin: 0 0 20px 0; font-size: 1.5em;">➕ Nouveau Client</h3>
        <form id="addCustomerForm" onsubmit="submitAddCustomer(event)">
            <div style="margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 5px; font-weight: 600; color: #333;">Nom</label>
                <input type="text" id="newCustomerName" placeholder="Nom du client" 
                       style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 10px; font-size: 1em; box-sizing: border-box;">
            </div>
            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 5px; font-weight: 600; color: #333;">Téléphone *</label>
                <input type="tel" id="newCustomerPhone" placeholder="06 12 34 56 78" required
                       style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 10px; font-size: 1em; box-sizing: border-box;">
            </div>
            <div style="display: flex; gap: 10px;">
                <button type="button" onclick="closeAddCustomerModal()" 
                        style="flex: 1; padding: 12px; background: #e0e0e0; border: none; border-radius: 10px; cursor: pointer; font-weight: 600;">
                    Annuler
                </button>
                <button type="submit" 
                        style="flex: 1; padding: 12px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 10px; cursor: pointer; font-weight: 600;">
                    Ajouter
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Ajouter Récompense -->
<div id="addRewardModal" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.7); z-index: 10000; align-items: center; justify-content: center;">
    <div style="background: #2a2a3e; border-radius: 20px; padding: 30px; max-width: 450px; width: 90%; box-shadow: 0 20px 60px rgba(0,0,0,0.5);">
        <h3 style="margin: 0 0 20px 0; font-size: 1.3em; color: #f59e0b;"><i class="fas fa-gift"></i> Nouvelle Récompense</h3>
        <form id="addRewardForm" onsubmit="submitAddReward(event)">
            <div style="margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 5px; font-weight: 600; color: #d1d5db;">Nom de la récompense *</label>
                <input type="text" id="rewardName" placeholder="Ex: Menu offert" required
                       style="width: 100%; padding: 12px; border: 1px solid #374151; border-radius: 10px; font-size: 1em; box-sizing: border-box; background: #1e293b; color: white;">
            </div>
            <div style="margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 5px; font-weight: 600; color: #d1d5db;">Description</label>
                <textarea id="rewardDescription" placeholder="Description optionnelle..." rows="2"
                       style="width: 100%; padding: 12px; border: 1px solid #374151; border-radius: 10px; font-size: 1em; box-sizing: border-box; background: #1e293b; color: white;"></textarea>
            </div>
            <div style="margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 5px; font-weight: 600; color: #d1d5db;">Points requis *</label>
                <input type="number" id="rewardPoints" value="100" min="1" required
                       style="width: 100%; padding: 12px; border: 1px solid #374151; border-radius: 10px; font-size: 1em; box-sizing: border-box; background: #1e293b; color: white;">
            </div>
            <div style="margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 5px; font-weight: 600; color: #d1d5db;">Type de récompense *</label>
                <select id="rewardType" onchange="toggleRewardValue()" required
                       style="width: 100%; padding: 12px; border: 1px solid #374151; border-radius: 10px; font-size: 1em; box-sizing: border-box; background: #1e293b; color: white;">
                    <option value="discount_percent">Réduction en %</option>
                    <option value="discount_amount">Réduction en DA</option>
                    <option value="free_product">Produit gratuit</option>
                    <option value="free_delivery">Livraison gratuite</option>
                </select>
            </div>
            <div style="margin-bottom: 20px;" id="rewardValueContainer">
                <label style="display: block; margin-bottom: 5px; font-weight: 600; color: #d1d5db;">Valeur de la réduction</label>
                <input type="number" id="rewardValue" value="10" min="1"
                       style="width: 100%; padding: 12px; border: 1px solid #374151; border-radius: 10px; font-size: 1em; box-sizing: border-box; background: #1e293b; color: white;">
            </div>
            <div style="display: flex; gap: 10px;">
                <button type="button" onclick="closeAddRewardModal()"
                        style="flex: 1; padding: 12px; background: #374151; color: white; border: none; border-radius: 10px; cursor: pointer; font-weight: 600;">
                    Annuler
                </button>
                <button type="submit"
                        style="flex: 1; padding: 12px; background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: white; border: none; border-radius: 10px; cursor: pointer; font-weight: 600;">
                    <i class="fas fa-plus"></i> Créer
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Ajouter Points -->
<div id="addPointsModal" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.7); z-index: 10000; align-items: center; justify-content: center;">
    <div style="background: #2a2a3e; border-radius: 20px; padding: 30px; max-width: 400px; width: 90%; box-shadow: 0 20px 60px rgba(0,0,0,0.5);">
        <h3 style="margin: 0 0 20px 0; font-size: 1.3em; color: #f59e0b;"><i class="fas fa-star"></i> Ajouter des Points</h3>
        <p style="color: #9ca3af; margin-bottom: 15px;">Client : <strong id="pointsCustomerName" style="color: white;"></strong></p>
        <input type="hidden" id="pointsCustomerId">
        <form id="addPointsForm" onsubmit="submitAddPoints(event)">
            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 5px; font-weight: 600; color: #d1d5db;">Nombre de points</label>
                <input type="number" id="pointsAmount" value="10" required
                       style="width: 100%; padding: 12px; border: 1px solid #374151; border-radius: 10px; font-size: 1em; box-sizing: border-box; background: #1e293b; color: white; text-align: center; font-size: 24px;">
                <p style="color: #6b7280; font-size: 12px; margin-top: 8px;"><i class="fas fa-info-circle"></i> Utilisez des valeurs négatives pour retirer des points</p>
            </div>
            <div style="display: flex; gap: 10px;">
                <button type="button" onclick="closeAddPointsModal()"
                        style="flex: 1; padding: 12px; background: #374151; color: white; border: none; border-radius: 10px; cursor: pointer; font-weight: 600;">
                    Annuler
                </button>
                <button type="submit"
                        style="flex: 1; padding: 12px; background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: white; border: none; border-radius: 10px; cursor: pointer; font-weight: 600;">
                    <i class="fas fa-plus"></i> Ajouter
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Utiliser Points (Redeem) -->
<div id="redeemModal" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.8); z-index: 10000; align-items: center; justify-content: center; overflow-y: auto; padding: 20px;">
    <div style="background: #2a2a3e; border-radius: 20px; padding: 25px; max-width: 500px; width: 100%; box-shadow: 0 20px 60px rgba(0,0,0,0.5); margin: auto;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h3 style="margin: 0; color: #10b981;"><i class="fas fa-exchange-alt"></i> Utiliser des points</h3>
            <button onclick="closeRedeemModal()" style="background: none; border: none; color: #9ca3af; font-size: 20px; cursor: pointer;"><i class="fas fa-times"></i></button>
        </div>

        <!-- Recherche client -->
        <div style="margin-bottom: 20px;">
            <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #d1d5db;">Rechercher le client</label>
            <input type="text" id="redeemSearchInput" placeholder="Nom, téléphone ou code fidélité..."
                   oninput="searchCustomerForRedeem(this.value)"
                   style="width: 100%; padding: 12px; border: 1px solid #374151; border-radius: 10px; background: #1e293b; color: white; font-size: 15px;">
            <div id="redeemSearchResults" style="margin-top: 10px; max-height: 200px; overflow-y: auto;"></div>
        </div>

        <!-- Client sélectionné -->
        <div id="redeemSelectedCustomer" style="display: none; background: #1e293b; border-radius: 12px; padding: 15px; margin-bottom: 20px; border: 2px solid #10b981;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                <div>
                    <div style="font-weight: bold; font-size: 16px;" id="redeemCustomerName"></div>
                    <div style="color: #9ca3af; font-size: 12px;" id="redeemCustomerPhone"></div>
                    <div style="color: #f59e0b; font-size: 11px; margin-top: 2px;" id="redeemCustomerCode"></div>
                </div>
                <div style="text-align: right;">
                    <div style="font-size: 28px; font-weight: bold; color: #f59e0b;" id="redeemCustomerPoints">0</div>
                    <div style="color: #9ca3af; font-size: 11px;">points</div>
                </div>
            </div>
            <input type="hidden" id="redeemCustomerId">
        </div>

        <!-- Récompenses disponibles -->
        <div id="redeemRewardsSection" style="display: none;">
            <label style="display: block; margin-bottom: 10px; font-weight: 600; color: #d1d5db;">Choisir une récompense</label>
            <div id="redeemRewardsList"></div>
        </div>

        <!-- Message si pas assez de points -->
        <div id="redeemNoRewards" style="display: none; text-align: center; padding: 20px; color: #6b7280;">
            <i class="fas fa-info-circle" style="font-size: 24px; margin-bottom: 10px;"></i>
            <p>Pas assez de points pour les récompenses disponibles</p>
        </div>
    </div>
</div>

        <!-- ARCHIVES -->
        <div id="section-archives" class="section">
            <!-- Header -->
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
                <h2><i class="fas fa-archive" style="color: #8b5cf6;"></i> Archives</h2>
                <div style="display: flex; gap: 10px; align-items: center;">
                    <select id="exportMonth" class="select" style="width: auto; padding: 8px 12px; font-size: 13px;">
                        <option value="">Tout l'historique</option>
                        <?php
                        // Générer les 12 derniers mois
                        for ($i = 0; $i < 12; $i++) {
                            $monthDate = strtotime("-$i months");
                            $monthVal = date('Y-m', $monthDate);
                            $monthLabel = ucfirst(strftime('%B %Y', $monthDate));
                            echo "<option value=\"$monthVal\">$monthLabel</option>";
                        }
                        ?>
                    </select>
                    <button onclick="exportArchives()" class="btn btn-sm btn-gray"><i class="fas fa-download"></i> Export CSV</button>
                </div>
            </div>

            <?php if (empty($archivedOrders)): ?>
                <div class="card" style="text-align: center; padding: 60px;">
                    <i class="fas fa-archive" style="font-size: 48px; color: #555; margin-bottom: 15px;"></i>
                    <p style="color: #9ca3af; font-size: 16px;">Aucune commande archivée</p>
                    <p style="color: #6b7280; font-size: 13px;">Les commandes terminées seront archivées ici</p>
                </div>
            <?php else: ?>
                <?php
                // Calculer les stats des archives
                $archiveTotal = array_sum(array_column($archivedOrders, 'total'));
                $archiveCount = count($archivedOrders);

                // Grouper par date
                $groupedByDate = [];
                foreach (array_reverse($archivedOrders) as $order) {
                    $date = date('Y-m-d', strtotime($order['created_at'] ?? 'now'));
                    if (!isset($groupedByDate[$date])) {
                        $groupedByDate[$date] = [];
                    }
                    $groupedByDate[$date][] = $order;
                }
                // Limiter à 30 jours
                $groupedByDate = array_slice($groupedByDate, 0, 30, true);
                ?>

                <!-- Stats archives -->
                <div class="stats" style="margin-bottom: 20px;">
                    <div class="stat-card" style="border-left: 4px solid #8b5cf6;">
                        <div style="color: #8b5cf6;"><i class="fas fa-receipt"></i></div>
                        <div class="stat-number" style="color: #8b5cf6;"><?php echo $archiveCount; ?></div>
                        <div style="color: #9ca3af; font-size: 11px;">Commandes</div>
                    </div>
                    <div class="stat-card" style="border-left: 4px solid <?php echo $primaryColor; ?>;">
                        <div style="color: <?php echo $primaryColor; ?>;"><i class="fas fa-coins"></i></div>
                        <div class="stat-number" style="color: <?php echo $primaryColor; ?>;"><?php echo number_format($archiveTotal, 0); ?> DA</div>
                        <div style="color: #9ca3af; font-size: 11px;">CA Total</div>
                    </div>
                    <div class="stat-card" style="border-left: 4px solid #10b981;">
                        <div style="color: #10b981;"><i class="fas fa-shopping-basket"></i></div>
                        <div class="stat-number" style="color: #10b981;"><?php echo $archiveCount > 0 ? number_format($archiveTotal / $archiveCount, 0) : 0; ?> DA</div>
                        <div style="color: #9ca3af; font-size: 11px;">Panier moyen</div>
                    </div>
                </div>

                <!-- Liste groupée par date -->
                <?php foreach ($groupedByDate as $date => $dateOrders):
                    $dateLabel = date('d/m/Y', strtotime($date));
                    $dayName = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'][date('w', strtotime($date))];
                    $dayTotal = array_sum(array_column($dateOrders, 'total'));

                    // Date relative
                    $daysAgo = floor((time() - strtotime($date)) / 86400);
                    if ($daysAgo === 0) {
                        $dateLabel = "Aujourd'hui";
                    } elseif ($daysAgo === 1) {
                        $dateLabel = "Hier";
                    } else {
                        $dateLabel = $dayName . ' ' . date('d/m', strtotime($date));
                    }
                ?>
                <div class="card" style="margin-bottom: 15px; border-left: 4px solid #8b5cf6;">
                    <div style="display: flex; justify-content: space-between; align-items: center; padding-bottom: 12px; border-bottom: 1px solid #374151; margin-bottom: 12px;">
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <div style="width: 40px; height: 40px; background: #8b5cf622; border-radius: 10px; display: flex; align-items: center; justify-content: center;">
                                <i class="fas fa-calendar-day" style="color: #8b5cf6;"></i>
                            </div>
                            <div>
                                <strong style="font-size: 14px;"><?php echo $dateLabel; ?></strong>
                                <div style="color: #9ca3af; font-size: 11px;"><?php echo count($dateOrders); ?> commande<?php echo count($dateOrders) > 1 ? 's' : ''; ?></div>
                            </div>
                        </div>
                        <div style="text-align: right;">
                            <div style="font-size: 18px; font-weight: bold; color: <?php echo $primaryColor; ?>;"><?php echo number_format($dayTotal, 0); ?> DA</div>
                        </div>
                    </div>

                    <div style="background: #1e293b; border-radius: 8px; overflow: hidden;">
                    <?php foreach (array_slice($dateOrders, 0, 10) as $idx => $order): ?>
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 10px 12px; <?php echo $idx > 0 ? 'border-top: 1px solid #374151;' : ''; ?>">
                        <div style="flex: 1; min-width: 0; display: flex; align-items: center; gap: 10px;">
                            <div style="width: 32px; height: 32px; border-radius: 50%; background: linear-gradient(135deg, <?php echo $primaryColor; ?>, #d97706); display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: bold; color: white;">
                                <?php echo strtoupper(substr($order['customer_name'] ?? 'C', 0, 1)); ?>
                            </div>
                            <div>
                                <div style="display: flex; align-items: center; gap: 6px;">
                                    <strong style="font-size: 13px;"><?php echo htmlspecialchars($order['customer_name'] ?? 'Client'); ?></strong>
                                    <span style="color: #6b7280; font-size: 10px;">#<?php echo htmlspecialchars(substr($order['id'], -6)); ?></span>
                                </div>
                                <div style="color: #6b7280; font-size: 11px;">
                                    <i class="fas fa-clock" style="font-size: 9px;"></i> <?php echo date('H:i', strtotime($order['created_at'])); ?>
                                    <?php if (!empty($order['items'])): ?>
                                    • <?php echo count($order['items']); ?> article<?php echo count($order['items']) > 1 ? 's' : ''; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div style="text-align: right;">
                            <div style="font-weight: bold; color: <?php echo $primaryColor; ?>; font-size: 14px;"><?php echo number_format($order['total'] ?? 0, 0); ?> DA</div>
                            <span style="background: #10b98122; color: #10b981; padding: 2px 8px; border-radius: 10px; font-size: 9px;"><i class="fas fa-check"></i> Terminée</span>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    </div>

                    <?php if (count($dateOrders) > 10): ?>
                    <div style="text-align: center; padding-top: 12px; color: #6b7280; font-size: 12px;">
                        <i class="fas fa-ellipsis-h"></i> et <?php echo count($dateOrders) - 10; ?> autre<?php echo (count($dateOrders) - 10) > 1 ? 's' : ''; ?>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- RÉGLAGES -->
        <div id="section-settings" class="section">
            <!-- Header -->
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2><i class="fas fa-cog" style="color: #6b7280;"></i> Réglages</h2>
            </div>

            <!-- Horaires -->
            <div class="card" style="border-left: 4px solid #3b82f6;">
                <h3 style="margin-bottom: 15px;"><i class="fas fa-clock" style="color: #3b82f6;"></i> Horaires d'ouverture</h3>
                <p style="color: #9ca3af; font-size: 12px; margin-bottom: 15px;">Ajoutez plusieurs créneaux par jour (midi + soir)</p>
                <form method="POST" id="hours-form">
                    <input type="hidden" name="action" value="save_settings">
                    <?php
                    $days = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'];
                    $hours = $restaurantSettings['openingHours'] ?? [];
                    foreach ($days as $i => $day):
                        $dayHours = $hours[$i] ?? ['opens' => '18:30', 'closes' => '23:30'];
                        // Support ancien format (single slot) et nouveau format (multiple slots)
                        $slots = isset($dayHours['slots']) ? $dayHours['slots'] : [['opens' => $dayHours['opens'] ?? '18:30', 'closes' => $dayHours['closes'] ?? '23:30']];
                    ?>
                    <div class="hours-day" data-day="<?php echo $i; ?>" style="margin-bottom: 12px; padding: 10px; background: rgba(0,0,0,0.2); border-radius: 8px;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                            <strong style="font-size: 14px;"><?php echo $day; ?></strong>
                            <button type="button" class="btn btn-sm btn-gray" onclick="addSlot(<?php echo $i; ?>)" style="padding: 4px 10px; font-size: 11px;">
                                <i class="fas fa-plus"></i> Créneau
                            </button>
                        </div>
                        <div class="slots-container" id="slots-<?php echo $i; ?>">
                            <?php foreach ($slots as $s => $slot): ?>
                            <div class="slot-row" style="display: flex; gap: 8px; align-items: center; margin-bottom: 6px;">
                                <input type="time" name="hours[<?php echo $i; ?>][slots][<?php echo $s; ?>][opens]" value="<?php echo $slot['opens']; ?>" style="flex: 1;">
                                <span style="color: #6b7280;">→</span>
                                <input type="time" name="hours[<?php echo $i; ?>][slots][<?php echo $s; ?>][closes]" value="<?php echo $slot['closes']; ?>" style="flex: 1;">
                                <?php if ($s > 0): ?>
                                <button type="button" class="btn btn-sm" style="background: #dc2626; padding: 4px 8px;" onclick="this.parentNode.remove()">
                                    <i class="fas fa-times"></i>
                                </button>
                                <?php endif; ?>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    <button type="submit" class="btn" style="margin-top: 15px;"><i class="fas fa-save"></i> Enregistrer</button>
                </form>
            </div>

            <!-- Livraison & Plateformes -->
            <div class="card" style="border-left: 4px solid #f59e0b;">
                <h3 style="margin-bottom: 15px;"><i class="fas fa-truck" style="color: #f59e0b;"></i> Livraison & Plateformes</h3>

                <!-- Toggle Livraison -->
                <div style="display: flex; align-items: center; justify-content: space-between; padding: 15px; background: rgba(0,0,0,0.2); border-radius: 10px; margin-bottom: 15px;">
                    <div>
                        <strong style="font-size: 14px;">Livraison activée</strong>
                        <p style="color: #9ca3af; font-size: 12px; margin: 4px 0 0;">Afficher les options de livraison sur le site</p>
                    </div>
                    <div id="delivery-toggle" onclick="toggleDelivery()" style="cursor: pointer;">
                        <div id="delivery-toggle-bg" style="width: 50px; height: 26px; border-radius: 13px; background: <?php echo ($restaurantSettings['delivery']['enabled'] ?? false) ? '#10b981' : '#4b5563'; ?>; position: relative; transition: background 0.3s;">
                            <div id="delivery-toggle-knob" style="width: 22px; height: 22px; border-radius: 50%; background: white; position: absolute; top: 2px; left: <?php echo ($restaurantSettings['delivery']['enabled'] ?? false) ? '26px' : '2px'; ?>; transition: left 0.3s;"></div>
                        </div>
                    </div>
                </div>

                <!-- Plateformes de livraison -->
                <div style="margin-top: 20px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                        <strong style="font-size: 14px;">Plateformes de livraison</strong>
                        <button type="button" class="btn btn-sm btn-gray" onclick="openAddPlatformModal()"><i class="fas fa-plus"></i> Ajouter</button>
                    </div>
                    <div id="platforms-list">
                        <?php foreach (($restaurantSettings['platforms'] ?? []) as $platform): ?>
                        <div class="platform-row" data-id="<?php echo htmlspecialchars($platform['id']); ?>" style="display: flex; align-items: center; gap: 12px; padding: 12px; background: rgba(0,0,0,0.2); border-radius: 10px; margin-bottom: 8px;">
                            <div style="flex: 1;">
                                <strong style="font-size: 13px;"><?php echo htmlspecialchars($platform['name']); ?></strong>
                                <a href="<?php echo htmlspecialchars($platform['url']); ?>" target="_blank" style="display: block; color: #60a5fa; font-size: 11px; text-overflow: ellipsis; overflow: hidden; white-space: nowrap;"><?php echo htmlspecialchars($platform['url']); ?></a>
                            </div>
                            <div onclick="togglePlatform('<?php echo htmlspecialchars($platform['id']); ?>')" style="cursor: pointer;">
                                <div class="platform-toggle" style="width: 40px; height: 22px; border-radius: 11px; background: <?php echo ($platform['enabled'] ?? true) ? '#10b981' : '#4b5563'; ?>; position: relative; transition: background 0.3s;">
                                    <div style="width: 18px; height: 18px; border-radius: 50%; background: white; position: absolute; top: 2px; left: <?php echo ($platform['enabled'] ?? true) ? '20px' : '2px'; ?>; transition: left 0.3s;"></div>
                                </div>
                            </div>
                            <button onclick="deletePlatform('<?php echo htmlspecialchars($platform['id']); ?>')" class="btn btn-sm" style="background: #dc2626; padding: 6px 10px;"><i class="fas fa-trash"></i></button>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Modal Ajouter Plateforme -->
            <div id="add-platform-modal" style="display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.7); z-index: 1000; align-items: center; justify-content: center;">
                <div style="background: #1f2937; border-radius: 16px; padding: 24px; max-width: 400px; width: 90%;">
                    <h3 style="margin: 0 0 20px;"><i class="fas fa-plus"></i> Ajouter une plateforme</h3>
                    <div class="form-group" style="margin-bottom: 15px;">
                        <label>Nom de la plateforme</label>
                        <input type="text" id="new-platform-name" placeholder="Ex: Just Eat" style="width: 100%;">
                    </div>
                    <div class="form-group" style="margin-bottom: 20px;">
                        <label>URL de votre page</label>
                        <input type="url" id="new-platform-url" placeholder="https://..." style="width: 100%;">
                    </div>
                    <div style="display: flex; gap: 10px; justify-content: flex-end;">
                        <button onclick="closeAddPlatformModal()" class="btn btn-gray">Annuler</button>
                        <button onclick="addPlatform()" class="btn"><i class="fas fa-plus"></i> Ajouter</button>
                    </div>
                </div>
            </div>

            <!-- Contact -->
            <div class="card" style="border-left: 4px solid #10b981;">
                <h3 style="margin-bottom: 15px;"><i class="fas fa-phone" style="color: #10b981;"></i> Contact & Réseaux</h3>
                <form method="POST" id="contact-form">
                    <input type="hidden" name="action" value="save_settings">

                    <!-- Téléphones -->
                    <div style="margin-bottom: 20px;">
                        <label style="display: block; margin-bottom: 8px; font-weight: 600;">Téléphones</label>
                        <div id="phones-container">
                            <div class="form-group dynamic-row" style="display: flex; gap: 8px; align-items: center;">
                                <input type="text" name="phone" value="<?php echo htmlspecialchars($restaurantSettings['contact']['phone'] ?? ''); ?>" placeholder="Téléphone principal" style="flex: 1;">
                            </div>
                            <?php
                            $extraPhones = $restaurantSettings['contact']['extra_phones'] ?? [];
                            foreach ($extraPhones as $i => $ep): ?>
                            <div class="form-group dynamic-row" style="display: flex; gap: 8px; align-items: center;">
                                <input type="text" name="extra_phones[]" value="<?php echo htmlspecialchars($ep); ?>" placeholder="Numéro supplémentaire" style="flex: 1;">
                                <button type="button" class="btn btn-sm" style="background: #dc2626; padding: 8px 12px;" onclick="this.parentNode.remove()"><i class="fas fa-times"></i></button>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <button type="button" class="btn btn-sm btn-gray" onclick="addPhone()" style="margin-top: 8px;"><i class="fas fa-plus"></i> Ajouter un numéro</button>
                    </div>

                    <div class="form-group">
                        <label>WhatsApp (numéro sans +)</label>
                        <input type="text" name="whatsapp" value="<?php echo htmlspecialchars($restaurantSettings['contact']['whatsappOrdersNumber'] ?? ''); ?>">
                    </div>

                    <!-- Réseaux sociaux -->
                    <div style="margin-bottom: 20px; margin-top: 20px; border-top: 1px solid #374151; padding-top: 20px;">
                        <label style="display: block; margin-bottom: 8px; font-weight: 600;">Réseaux sociaux</label>
                        <div id="socials-container">
                            <div class="form-group dynamic-row" style="display: flex; gap: 8px; align-items: center;">
                                <select name="social_type[]" style="width: 130px; padding: 10px; background: #1a1a2e; border: 1px solid #374151; border-radius: 8px; color: #fff;">
                                    <option value="instagram" selected>Instagram</option>
                                    <option value="facebook">Facebook</option>
                                    <option value="tiktok">TikTok</option>
                                    <option value="snapchat">Snapchat</option>
                                    <option value="twitter">Twitter/X</option>
                                    <option value="youtube">YouTube</option>
                                    <option value="other">Autre</option>
                                </select>
                                <input type="text" name="social_value[]" value="<?php echo htmlspecialchars($restaurantSettings['social']['instagram'] ?? ''); ?>" placeholder="Lien ou @pseudo" style="flex: 1;">
                            </div>
                            <?php if (!empty($restaurantSettings['social']['facebook'])): ?>
                            <div class="form-group dynamic-row" style="display: flex; gap: 8px; align-items: center;">
                                <select name="social_type[]" style="width: 130px; padding: 10px; background: #1a1a2e; border: 1px solid #374151; border-radius: 8px; color: #fff;">
                                    <option value="instagram">Instagram</option>
                                    <option value="facebook" selected>Facebook</option>
                                    <option value="tiktok">TikTok</option>
                                    <option value="snapchat">Snapchat</option>
                                    <option value="twitter">Twitter/X</option>
                                    <option value="youtube">YouTube</option>
                                    <option value="other">Autre</option>
                                </select>
                                <input type="text" name="social_value[]" value="<?php echo htmlspecialchars($restaurantSettings['social']['facebook']); ?>" placeholder="Lien ou @pseudo" style="flex: 1;">
                                <button type="button" class="btn btn-sm" style="background: #dc2626; padding: 8px 12px;" onclick="this.parentNode.remove()"><i class="fas fa-times"></i></button>
                            </div>
                            <?php endif; ?>
                            <?php if (!empty($restaurantSettings['social']['tiktok'])): ?>
                            <div class="form-group dynamic-row" style="display: flex; gap: 8px; align-items: center;">
                                <select name="social_type[]" style="width: 130px; padding: 10px; background: #1a1a2e; border: 1px solid #374151; border-radius: 8px; color: #fff;">
                                    <option value="instagram">Instagram</option>
                                    <option value="facebook">Facebook</option>
                                    <option value="tiktok" selected>TikTok</option>
                                    <option value="snapchat">Snapchat</option>
                                    <option value="twitter">Twitter/X</option>
                                    <option value="youtube">YouTube</option>
                                    <option value="other">Autre</option>
                                </select>
                                <input type="text" name="social_value[]" value="<?php echo htmlspecialchars($restaurantSettings['social']['tiktok']); ?>" placeholder="Lien ou @pseudo" style="flex: 1;">
                                <button type="button" class="btn btn-sm" style="background: #dc2626; padding: 8px 12px;" onclick="this.parentNode.remove()"><i class="fas fa-times"></i></button>
                            </div>
                            <?php endif; ?>
                            <?php if (!empty($restaurantSettings['social']['snapchat'])): ?>
                            <div class="form-group dynamic-row" style="display: flex; gap: 8px; align-items: center;">
                                <select name="social_type[]" style="width: 130px; padding: 10px; background: #1a1a2e; border: 1px solid #374151; border-radius: 8px; color: #fff;">
                                    <option value="instagram">Instagram</option>
                                    <option value="facebook">Facebook</option>
                                    <option value="tiktok">TikTok</option>
                                    <option value="snapchat" selected>Snapchat</option>
                                    <option value="twitter">Twitter/X</option>
                                    <option value="youtube">YouTube</option>
                                    <option value="other">Autre</option>
                                </select>
                                <input type="text" name="social_value[]" value="<?php echo htmlspecialchars($restaurantSettings['social']['snapchat']); ?>" placeholder="Lien ou @pseudo" style="flex: 1;">
                                <button type="button" class="btn btn-sm" style="background: #dc2626; padding: 8px 12px;" onclick="this.parentNode.remove()"><i class="fas fa-times"></i></button>
                            </div>
                            <?php endif; ?>
                            <?php
                            $extraSocials = $restaurantSettings['social']['extra'] ?? [];
                            foreach ($extraSocials as $es): ?>
                            <div class="form-group dynamic-row" style="display: flex; gap: 8px; align-items: center;">
                                <select name="social_type[]" style="width: 130px; padding: 10px; background: #1a1a2e; border: 1px solid #374151; border-radius: 8px; color: #fff;">
                                    <option value="instagram" <?php echo ($es['type'] ?? '') === 'instagram' ? 'selected' : ''; ?>>Instagram</option>
                                    <option value="facebook" <?php echo ($es['type'] ?? '') === 'facebook' ? 'selected' : ''; ?>>Facebook</option>
                                    <option value="tiktok" <?php echo ($es['type'] ?? '') === 'tiktok' ? 'selected' : ''; ?>>TikTok</option>
                                    <option value="snapchat" <?php echo ($es['type'] ?? '') === 'snapchat' ? 'selected' : ''; ?>>Snapchat</option>
                                    <option value="twitter" <?php echo ($es['type'] ?? '') === 'twitter' ? 'selected' : ''; ?>>Twitter/X</option>
                                    <option value="youtube" <?php echo ($es['type'] ?? '') === 'youtube' ? 'selected' : ''; ?>>YouTube</option>
                                    <option value="other" <?php echo ($es['type'] ?? '') === 'other' ? 'selected' : ''; ?>>Autre</option>
                                </select>
                                <input type="text" name="social_value[]" value="<?php echo htmlspecialchars($es['value'] ?? ''); ?>" placeholder="Lien ou @pseudo" style="flex: 1;">
                                <button type="button" class="btn btn-sm" style="background: #dc2626; padding: 8px 12px;" onclick="this.parentNode.remove()"><i class="fas fa-times"></i></button>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <button type="button" class="btn btn-sm btn-gray" onclick="addSocial()" style="margin-top: 8px;"><i class="fas fa-plus"></i> Ajouter un réseau</button>
                    </div>

                    <button type="submit" class="btn"><i class="fas fa-save"></i> Enregistrer</button>
                </form>
            </div>

            <script>
            function addPhone() {
                const container = document.getElementById('phones-container');
                const div = document.createElement('div');
                div.className = 'form-group dynamic-row';
                div.style.cssText = 'display: flex; gap: 8px; align-items: center;';
                div.innerHTML = `
                    <input type="text" name="extra_phones[]" placeholder="Numéro supplémentaire" style="flex: 1;">
                    <button type="button" class="btn btn-sm" style="background: #dc2626; padding: 8px 12px;" onclick="this.parentNode.remove()"><i class="fas fa-times"></i></button>
                `;
                container.appendChild(div);
            }

            function addSlot(dayIndex) {
                const container = document.getElementById('slots-' + dayIndex);
                const slotCount = container.querySelectorAll('.slot-row').length;
                const div = document.createElement('div');
                div.className = 'slot-row';
                div.style.cssText = 'display: flex; gap: 8px; align-items: center; margin-bottom: 6px;';
                div.innerHTML = `
                    <input type="time" name="hours[${dayIndex}][slots][${slotCount}][opens]" value="12:00" style="flex: 1;">
                    <span style="color: #6b7280;">→</span>
                    <input type="time" name="hours[${dayIndex}][slots][${slotCount}][closes]" value="14:00" style="flex: 1;">
                    <button type="button" class="btn btn-sm" style="background: #dc2626; padding: 4px 8px;" onclick="this.parentNode.remove()">
                        <i class="fas fa-times"></i>
                    </button>
                `;
                container.appendChild(div);
            }

            function addSocial() {
                const container = document.getElementById('socials-container');
                const div = document.createElement('div');
                div.className = 'form-group dynamic-row';
                div.style.cssText = 'display: flex; gap: 8px; align-items: center;';
                div.innerHTML = `
                    <select name="social_type[]" style="width: 130px; padding: 10px; background: #1a1a2e; border: 1px solid #374151; border-radius: 8px; color: #fff;">
                        <option value="instagram">Instagram</option>
                        <option value="facebook">Facebook</option>
                        <option value="tiktok">TikTok</option>
                        <option value="snapchat">Snapchat</option>
                        <option value="twitter">Twitter/X</option>
                        <option value="youtube">YouTube</option>
                        <option value="other">Autre</option>
                    </select>
                    <input type="text" name="social_value[]" placeholder="Lien ou @pseudo" style="flex: 1;">
                    <button type="button" class="btn btn-sm" style="background: #dc2626; padding: 8px 12px;" onclick="this.parentNode.remove()"><i class="fas fa-times"></i></button>
                `;
                container.appendChild(div);
            }
            </script>
            <!-- WhatsApp Business API -->
            <div class="card" style="border-left: 4px solid #25D366;">
                <h3 style="margin-bottom: 15px;"><i class="fab fa-whatsapp" style="color: #25D366;"></i> WhatsApp Business API</h3>
                <p style="color: #9ca3af; font-size: 12px; margin-bottom: 15px;">
                    Pour envoyer des messages automatiques via l'API WhatsApp Business, vous devez configurer votre token d'accès.
                    <a href="https://developers.facebook.com/docs/whatsapp/business-management-api" target="_blank" style="color: #60a5fa;">En savoir plus →</a>
                </p>
                <form method="POST">
                    <input type="hidden" name="action" value="save_whatsapp_config">
                    <div class="form-group">
                        <label>Token d'accès WhatsApp Business API</label>
                        <input type="password" name="whatsapp_token" id="whatsapp_token"
                               value="<?php echo htmlspecialchars($restaurantSettings['whatsapp']['token'] ?? ''); ?>"
                               placeholder="Entrez votre token WhatsApp Business API"
                               style="font-family: monospace;">
                        <button type="button" onclick="toggleTokenVisibility()" class="btn btn-sm btn-gray" style="margin-top: 8px;">
                            <i class="fas fa-eye" id="toggle-eye"></i> Afficher/Masquer
                        </button>
                    </div>
                    <div class="form-group">
                        <label>ID du numéro de téléphone WhatsApp</label>
                        <input type="text" name="whatsapp_phone_id"
                               value="<?php echo htmlspecialchars($restaurantSettings['whatsapp']['phoneNumberId'] ?? ''); ?>"
                               placeholder="Ex: 123456789012345">
                    </div>
                    <div class="form-group">
                        <label>ID du Business Account</label>
                        <input type="text" name="whatsapp_business_id"
                               value="<?php echo htmlspecialchars($restaurantSettings['whatsapp']['businessAccountId'] ?? ''); ?>"
                               placeholder="Ex: 123456789012345">
                    </div>
                    <div style="background: #1e293b; padding: 12px; border-radius: 8px; margin-bottom: 15px;">
                        <p style="color: #f59e0b; font-size: 12px; margin: 0;">
                            <i class="fas fa-exclamation-triangle"></i> <strong>Important:</strong> Le token doit être gardé secret.
                        </p>
                    </div>
                    <button type="submit" class="btn btn-whatsapp"><i class="fab fa-whatsapp"></i> Enregistrer la configuration</button>
                </form>
            </div>


            <!-- FAQ -->
            <div class="card" style="border-left: 4px solid #8b5cf6;">
                <h3 style="margin-bottom: 15px;"><i class="fas fa-question-circle" style="color: #8b5cf6;"></i> FAQ</h3>
                <form method="POST" id="faq-form">
                    <input type="hidden" name="action" value="save_faq">
                    <div id="faq-items">
                    <?php foreach ($restaurantSettings['faq']['items'] ?? [] as $i => $faq): ?>
                        <div class="faq-item" style="background: #1e293b; padding: 12px; border-radius: 8px; margin-bottom: 10px;">
                            <input type="text" name="faq_q[]" value="<?php echo htmlspecialchars($faq['question']); ?>" placeholder="Question" style="width: 100%; padding: 8px; background: #2a2a3e; border: 1px solid #444; border-radius: 6px; color: white; margin-bottom: 8px;">
                            <textarea name="faq_a[]" placeholder="Réponse" style="width: 100%; padding: 8px; background: #2a2a3e; border: 1px solid #444; border-radius: 6px; color: white; min-height: 60px;"><?php echo htmlspecialchars($faq['answer']); ?></textarea>
                        </div>
                    <?php endforeach; ?>
                    </div>
                    <button type="button" onclick="addFaqItem()" class="btn btn-sm btn-gray" style="margin-bottom: 15px;"><i class="fas fa-plus"></i> Ajouter une question</button>
                    <br>
                    <button type="submit" class="btn"><i class="fas fa-save"></i> Enregistrer FAQ</button>
                </form>
            </div>

            <!-- Produits -->
            <div class="card" style="border-left: 4px solid #f59e0b;">
                <h3 style="margin-bottom: 15px;"><i class="fas fa-utensils" style="color: #f59e0b;"></i> Gestion des produits</h3>
                <p style="color: #9ca3af; font-size: 13px; margin-bottom: 15px;">Gérez votre menu, ajoutez des produits, modifiez les prix et les catégories.</p>
                <a href="products-manager.php" class="btn" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);"><i class="fas fa-burger"></i> Gérer le menu</a>
            </div>

            <!-- Sécurité PIN -->
            <div class="card" style="border-left: 4px solid #ef4444;">
                <h3 style="margin-bottom: 15px;"><i class="fas fa-lock" style="color: #ef4444;"></i> Code PIN (Stats & Archives)</h3>
                <p style="color: #9ca3af; font-size: 13px; margin-bottom: 15px;">Modifiez le code PIN pour accéder aux statistiques et archives. Nécessite l'ancien PIN.</p>
                <div id="pinChangeForm">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 15px;">
                        <div>
                            <label style="color: #9ca3af; font-size: 11px; display: block; margin-bottom: 5px;">Ancien PIN</label>
                            <input type="password" id="oldPinInput" maxlength="8" placeholder="••••" style="width: 100%; padding: 10px; background: #2a2a3e; border: 1px solid #444; border-radius: 8px; color: #fff;">
                        </div>
                        <div>
                            <label style="color: #9ca3af; font-size: 11px; display: block; margin-bottom: 5px;">Nouveau PIN (4-8 chiffres)</label>
                            <input type="password" id="newPinInput" maxlength="8" placeholder="••••" style="width: 100%; padding: 10px; background: #2a2a3e; border: 1px solid #444; border-radius: 8px; color: #fff;">
                        </div>
                    </div>
                    <button type="button" onclick="changePin()" class="btn" style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);"><i class="fas fa-key"></i> Changer le PIN</button>
                    <p id="pinChangeResult" style="margin-top: 10px; font-size: 12px; display: none;"></p>
                </div>
            </div>
        </div>

        <!-- STATS -->
        <div id="section-stats" class="section">
            <!-- Header -->
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
                <h2><i class="fas fa-chart-line" style="color: #3b82f6;"></i> Statistiques</h2>
                <div style="display: flex; gap: 8px;">
                    <a href="?export=stats&period=week" class="btn btn-sm btn-gray"><i class="fas fa-download"></i> Semaine</a>
                    <a href="?export=stats&period=month" class="btn btn-sm btn-gray"><i class="fas fa-download"></i> Mois</a>
                </div>
            </div>

            <!-- CA Cards -->
            <div class="stats" style="grid-template-columns: repeat(3, 1fr); margin-bottom: 20px;">
                <div class="stat-card" style="border-left: 4px solid #10b981;">
                    <div style="color: #10b981;"><i class="fas fa-calendar-day"></i></div>
                    <div class="stat-number" style="color: #10b981;"><?php echo number_format($stats['revenue'] ?? 0, 0); ?> DA</div>
                    <div style="color: #9ca3af; font-size: 11px;">Aujourd'hui</div>
                    <div style="color: #6b7280; font-size: 10px; margin-top: 4px;"><?php echo $stats['today'] ?? 0; ?> commandes</div>
                </div>
                <div class="stat-card" style="border-left: 4px solid #3b82f6;">
                    <div style="color: #3b82f6;"><i class="fas fa-calendar-week"></i></div>
                    <div class="stat-number" style="color: #3b82f6;"><?php echo number_format($weekStats['revenue'] ?? 0, 0); ?> DA</div>
                    <div style="color: #9ca3af; font-size: 11px;">Semaine</div>
                    <div style="color: #6b7280; font-size: 10px; margin-top: 4px;"><?php echo $weekStats['orders'] ?? 0; ?> commandes</div>
                </div>
                <div class="stat-card" style="border-left: 4px solid #8b5cf6;">
                    <div style="color: #8b5cf6;"><i class="fas fa-calendar-alt"></i></div>
                    <div class="stat-number" style="color: #8b5cf6;"><?php echo number_format($monthStats['revenue'] ?? 0, 0); ?> DA</div>
                    <div style="color: #9ca3af; font-size: 11px;">Mois</div>
                    <div style="color: #6b7280; font-size: 10px; margin-top: 4px;"><?php echo $monthStats['orders'] ?? 0; ?> commandes</div>
                </div>
            </div>

            <!-- Panier moyen & Heure de pic -->
            <div class="stats" style="grid-template-columns: repeat(2, 1fr); margin-bottom: 20px;">
                <div class="stat-card" style="border-left: 4px solid <?php echo $primaryColor; ?>;">
                    <div style="color: <?php echo $primaryColor; ?>;"><i class="fas fa-shopping-basket"></i></div>
                    <div class="stat-number" style="color: <?php echo $primaryColor; ?>;"><?php echo number_format($monthStats['avg_order'] ?? 0, 0); ?> DA</div>
                    <div style="color: #9ca3af; font-size: 11px;">Panier moyen</div>
                </div>
                <div class="stat-card" style="border-left: 4px solid #f59e0b;">
                    <div style="color: #f59e0b;"><i class="fas fa-fire"></i></div>
                    <div class="stat-number" style="color: #f59e0b;"><?php echo $stats['peak_hour'] ?? '--:--'; ?></div>
                    <div style="color: #9ca3af; font-size: 11px;">Heure de pic</div>
                </div>
            </div>

            <!-- Top Produits -->
            <div class="card" style="border-left: 4px solid #f59e0b;">
                <h3 style="margin-bottom: 15px;"><i class="fas fa-trophy" style="color: #f59e0b;"></i> Top 5 Produits (30j)</h3>
                <?php if (empty($topProducts)): ?>
                    <div style="text-align: center; padding: 30px; color: #6b7280;">
                        <i class="fas fa-chart-pie" style="font-size: 32px; margin-bottom: 10px; color: #444;"></i>
                        <p>Aucune donnée disponible</p>
                    </div>
                <?php else: ?>
                    <div style="background: #1e293b; border-radius: 8px; overflow: hidden;">
                    <?php foreach ($topProducts as $i => $product):
                        $medalColors = ['#f59e0b', '#9ca3af', '#cd7f32', '#374151', '#374151'];
                        $medalColor = $medalColors[$i] ?? '#374151';
                    ?>
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 12px; <?php echo $i > 0 ? 'border-top: 1px solid #374151;' : ''; ?>">
                        <div style="display: flex; align-items: center; gap: 12px;">
                            <span style="width: 28px; height: 28px; background: <?php echo $medalColor; ?>; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: bold; color: white;"><?php echo $i + 1; ?></span>
                            <span style="font-size: 14px; font-weight: 500;"><?php echo htmlspecialchars($product['name']); ?></span>
                        </div>
                        <div style="text-align: right;">
                            <div style="color: <?php echo $primaryColor; ?>; font-weight: bold; font-size: 14px;"><?php echo $product['qty']; ?> vendus</div>
                            <div style="color: #10b981; font-size: 12px;"><?php echo number_format($product['revenue'], 0); ?> DA</div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Heures de pic -->
            <div class="card" style="margin-top: 15px; border-left: 4px solid #3b82f6;">
                <h3 style="margin-bottom: 15px;"><i class="fas fa-chart-bar" style="color: #3b82f6;"></i> Répartition par heure (30j)</h3>
                <?php
                $maxCount = max(array_column($peakHours, 'count') ?: [1]);
                ?>
                <div style="background: #1e293b; padding: 15px; border-radius: 8px;">
                    <div style="display: flex; align-items: flex-end; gap: 4px; height: 100px;">
                        <?php for ($h = 11; $h <= 23; $h++):
                            $hourData = array_filter($peakHours, fn($p) => (int)$p['hour'] === $h);
                            $count = !empty($hourData) ? array_values($hourData)[0]['count'] : 0;
                            $height = $maxCount > 0 ? ($count / $maxCount) * 100 : 0;
                            $isPeak = $count === $maxCount && $count > 0;
                        ?>
                        <div style="flex: 1; display: flex; flex-direction: column; align-items: center;">
                            <?php if ($count > 0): ?>
                            <span style="font-size: 8px; color: <?php echo $isPeak ? '#f59e0b' : '#6b7280'; ?>; margin-bottom: 2px;"><?php echo $count; ?></span>
                            <?php endif; ?>
                            <div style="width: 100%; background: <?php echo $isPeak ? '#f59e0b' : '#3b82f6'; ?>; height: <?php echo max($height, 2); ?>px; border-radius: 4px 4px 0 0; min-height: 2px;"></div>
                            <span style="font-size: 9px; color: <?php echo $isPeak ? '#f59e0b' : '#6b7280'; ?>; margin-top: 4px; font-weight: <?php echo $isPeak ? 'bold' : 'normal'; ?>;"><?php echo $h; ?>h</span>
                        </div>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>

            <!-- CA 7 derniers jours -->
            <div class="card" style="margin-top: 15px; border-left: 4px solid #10b981;">
                <h3 style="margin-bottom: 15px;"><i class="fas fa-chart-area" style="color: #10b981;"></i> CA des 7 derniers jours</h3>
                <?php
                $maxRevenue = max(array_column($dailyRevenue, 'revenue') ?: [1]);
                $days = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'];
                ?>
                <div style="background: #1e293b; padding: 15px; border-radius: 8px;">
                    <div style="display: flex; align-items: flex-end; gap: 8px; height: 120px;">
                        <?php foreach ($dailyRevenue as $day):
                            $height = $maxRevenue > 0 ? ($day['revenue'] / $maxRevenue) * 100 : 0;
                            $dayName = $days[date('w', strtotime($day['date']))];
                            $isToday = $day['date'] === date('Y-m-d');
                        ?>
                        <div style="flex: 1; display: flex; flex-direction: column; align-items: center;">
                            <span style="font-size: 10px; color: <?php echo $isToday ? '#10b981' : '#9ca3af'; ?>; margin-bottom: 4px; font-weight: <?php echo $isToday ? 'bold' : 'normal'; ?>;"><?php echo number_format($day['revenue'], 0); ?> DA</span>
                            <div style="width: 100%; background: <?php echo $isToday ? 'linear-gradient(180deg, #10b981, #059669)' : '#374151'; ?>; height: <?php echo max($height, 4); ?>px; border-radius: 4px 4px 0 0;"></div>
                            <span style="font-size: 10px; color: <?php echo $isToday ? '#10b981' : '#6b7280'; ?>; margin-top: 4px; font-weight: <?php echo $isToday ? 'bold' : 'normal'; ?>;"><?php echo $dayName; ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- FIDÉLITÉ -->
        <div id="section-loyalty" class="section">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
                <h2><i class="fas fa-gift" style="color: #f59e0b;"></i> Programme Fidélité</h2>
                <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                    <button onclick="openRedeemModal()" class="btn btn-sm" style="background: #10b981;"><i class="fas fa-exchange-alt"></i> Utiliser points</button>
                    <button onclick="openAddRewardModal()" class="btn btn-sm" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);"><i class="fas fa-plus"></i> Récompense</button>
                </div>
            </div>

            <!-- Configuration -->
            <div class="card" style="margin-bottom: 20px;">
                <h3 style="margin-bottom: 15px;"><i class="fas fa-cog"></i> Configuration</h3>
                <div style="display: flex; flex-wrap: wrap; gap: 20px; align-items: center;">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <label style="color: #9ca3af;">Programme actif :</label>
                        <label class="switch" style="position: relative; display: inline-block; width: 50px; height: 26px;">
                            <input type="checkbox" id="loyaltyEnabled" <?= ($loyaltyConfig['enabled'] ?? true) ? 'checked' : '' ?> onchange="updateLoyaltyConfig()" style="opacity: 0; width: 0; height: 0;">
                            <span style="position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #374151; transition: .4s; border-radius: 26px;"></span>
                        </label>
                    </div>
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <label style="color: #9ca3af;">Points par 100 DA :</label>
                        <input type="number" id="pointsPerEuro" value="<?= $loyaltyConfig['points_per_euro'] ?? 1 ?>" min="1" max="100" onchange="updateLoyaltyConfig()" style="width: 70px; padding: 8px; background: #1e293b; border: 1px solid #374151; border-radius: 8px; color: white; text-align: center;">
                    </div>
                </div>
                <p style="color: #6b7280; font-size: 12px; margin-top: 10px;"><i class="fas fa-info-circle"></i> Les clients gagnent des points à chaque commande qu'ils peuvent échanger contre des récompenses.</p>
            </div>

            <!-- QR Code pour les clients -->
            <div class="card" style="margin-bottom: 20px; border: 2px dashed #f59e0b;">
                <h3 style="margin-bottom: 15px; color: #f59e0b;"><i class="fas fa-qrcode"></i> Carte de Fidélité Virtuelle</h3>
                <p style="color: #9ca3af; font-size: 13px; margin-bottom: 15px;">Les clients peuvent scanner ce QR code pour accéder à leur carte de fidélité virtuelle et voir leurs points.</p>
                <div style="display: flex; gap: 20px; align-items: center; flex-wrap: wrap;">
                    <div id="loyalty-qrcode" style="background: white; padding: 15px; border-radius: 12px; display: inline-block;">
                        <?php $loyaltyUrl = 'https://' . ($_SERVER['HTTP_HOST'] ?? 'votresite.com') . '/loyalty-card.php'; ?>
                        <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=<?= urlencode($loyaltyUrl) ?>" alt="QR Code Fidélité" width="150" height="150">
                    </div>
                    <div>
                        <p style="color: #d1d5db; font-size: 14px; margin-bottom: 10px;"><strong>Lien de la carte fidélité :</strong></p>
                        <div style="display: flex; gap: 8px;">
                            <input type="text" id="loyalty-url" value="<?= 'https://' . ($_SERVER['HTTP_HOST'] ?? 'votresite.com') . '/loyalty-card.php' ?>" readonly style="flex: 1; padding: 10px; background: #1e293b; border: 1px solid #374151; border-radius: 8px; color: white; font-size: 12px;">
                            <button onclick="copyLoyaltyUrl()" class="btn btn-sm btn-gray"><i class="fas fa-copy"></i></button>
                        </div>
                        <button onclick="printQRCode()" class="btn btn-sm" style="margin-top: 10px; background: #f59e0b;"><i class="fas fa-print"></i> Imprimer le QR Code</button>
                    </div>
                </div>
            </div>

            <!-- Récompenses disponibles -->
            <div class="card" style="margin-bottom: 20px;">
                <h3 style="margin-bottom: 15px;"><i class="fas fa-trophy" style="color: #f59e0b;"></i> Récompenses disponibles</h3>
                <?php if (empty($loyaltyRewards)): ?>
                    <div style="text-align: center; padding: 40px; color: #6b7280;">
                        <i class="fas fa-gift" style="font-size: 48px; margin-bottom: 15px; color: #444;"></i>
                        <p>Aucune récompense configurée</p>
                        <button onclick="openAddRewardModal()" class="btn btn-sm" style="margin-top: 10px; background: #f59e0b;"><i class="fas fa-plus"></i> Créer une récompense</button>
                    </div>
                <?php else: ?>
                    <div style="display: grid; gap: 12px;">
                        <?php foreach ($loyaltyRewards as $reward):
                            $typeLabels = [
                                'discount_percent' => 'Réduction %',
                                'discount_amount' => 'Réduction DA',
                                'free_product' => 'Produit gratuit',
                                'free_delivery' => 'Livraison gratuite'
                            ];
                            $typeLabel = $typeLabels[$reward['reward_type'] ?? 'discount_percent'] ?? $reward['reward_type'];
                        ?>
                        <div style="display: flex; justify-content: space-between; align-items: center; padding: 15px; background: #1e293b; border-radius: 10px; border-left: 4px solid #f59e0b;">
                            <div>
                                <h4 style="margin: 0 0 5px 0; font-size: 15px;"><?= htmlspecialchars($reward['name']) ?></h4>
                                <p style="margin: 0; color: #9ca3af; font-size: 12px;"><?= htmlspecialchars($reward['description'] ?? '') ?></p>
                                <div style="margin-top: 8px;">
                                    <span style="background: #f59e0b; color: white; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: bold;">
                                        <i class="fas fa-star"></i> <?= $reward['points_required'] ?> points
                                    </span>
                                    <span style="background: #374151; color: #d1d5db; padding: 3px 10px; border-radius: 20px; font-size: 11px; margin-left: 5px;">
                                        <?= $typeLabel ?>
                                        <?php if ($reward['reward_type'] !== 'free_product' && $reward['reward_type'] !== 'free_delivery'): ?>
                                            : <?= $reward['reward_value'] ?><?= $reward['reward_type'] === 'discount_percent' ? '%' : ' DA' ?>
                                        <?php endif; ?>
                                    </span>
                                </div>
                            </div>
                            <button onclick="deleteReward(<?= $reward['id'] ?>)" class="btn btn-sm" style="background: #ef4444;"><i class="fas fa-trash"></i></button>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Leaderboard -->
            <div class="card">
                <h3 style="margin-bottom: 15px;"><i class="fas fa-medal" style="color: #f59e0b;"></i> Top 10 Clients Fidèles</h3>
                <?php if (empty($loyaltyLeaderboard)): ?>
                    <p style="color: #6b7280; text-align: center; padding: 20px;">Aucune donnée de fidélité</p>
                <?php else: ?>
                    <div style="display: grid; gap: 8px;">
                        <?php foreach ($loyaltyLeaderboard as $i => $member):
                            $medalColors = ['#f59e0b', '#9ca3af', '#cd7f32'];
                            $medalColor = $medalColors[$i] ?? '#374151';
                            $memberName = $member['name'] ?? $member['customer_name'] ?? 'Client';
                            $memberPhone = $member['phone'] ?? $member['customer_phone'] ?? '';
                            $memberPoints = $member['loyalty_points'] ?? $member['total_points'] ?? 0;
                            $memberOrders = $member['orders_count'] ?? $member['rewards_redeemed'] ?? 0;
                        ?>
                        <div style="display: flex; align-items: center; gap: 12px; padding: 12px; background: #1e293b; border-radius: 8px;">
                            <div style="width: 32px; height: 32px; background: <?= $medalColor ?>; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 14px;">
                                <?= $i + 1 ?>
                            </div>
                            <div style="flex: 1;">
                                <div style="font-weight: 600; font-size: 14px;"><?= htmlspecialchars($memberName) ?></div>
                                <div style="color: #6b7280; font-size: 11px;"><?= htmlspecialchars($memberPhone) ?></div>
                            </div>
                            <div style="text-align: right;">
                                <div style="font-weight: bold; color: #f59e0b;"><?= number_format($memberPoints) ?> pts</div>
                                <div style="font-size: 11px; color: #6b7280;"><?= $memberOrders ?> commandes</div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <!-- FIN FIDÉLITÉ -->

        <!-- PRODUITS (simplifié) -->
        <div id="section-products" class="section">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2>Produits</h2>
                <a href="products-manager.php" class="btn btn-green"><i class="fas fa-cog"></i> Gérer</a>
            </div>
            <?php foreach ($products as $category): ?>
            <div class="card">
                <h3 style="margin-bottom: 10px; color: <?php echo $primaryColor; ?>;"><?php echo htmlspecialchars($category['name'] ?? ''); ?></h3>
                <?php foreach ($category['items'] ?? [] as $item): ?>
                <div style="display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #374151;">
                    <span><?php echo htmlspecialchars($item['name'] ?? ''); ?></span>
                    <span style="color: <?php echo $primaryColor; ?>;"><?php echo number_format($item['priceSolo'] ?? $item['price'] ?? 0, 0); ?> DA</span>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Navigation -->
    <div class="bottom-nav">
        <button class="nav-btn active" data-section="orders"><i class="fas fa-receipt"></i><div>Commandes</div></button>
        <button class="nav-btn" data-section="customers"><i class="fas fa-users"></i><div>Clients</div></button>
        <button class="nav-btn" data-section="loyalty"><i class="fas fa-gift"></i><div>Fidélité</div></button>
        <button class="nav-btn" data-section="stats"><i class="fas fa-chart-line"></i><div>Stats</div></button>
        <button class="nav-btn" data-section="archives"><i class="fas fa-archive"></i><div>Archives</div></button>
        <button class="nav-btn" data-section="settings"><i class="fas fa-cog"></i><div>Réglages</div></button>
    </div>

    <!-- Modal PIN -->
    <div id="pinModal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.8); z-index:9999; align-items:center; justify-content:center;">
        <div style="background:#1a1a2e; border-radius:16px; padding:30px; max-width:320px; width:90%; text-align:center; box-shadow:0 20px 60px rgba(0,0,0,0.5);">
            <div style="font-size:48px; margin-bottom:15px;">🔒</div>
            <h3 style="margin:0 0 10px; color:#fff;">Accès restreint</h3>
            <p style="color:#9ca3af; font-size:13px; margin-bottom:20px;">Entrez le code PIN pour accéder à cette section</p>
            <div style="display:flex; gap:8px; justify-content:center; margin-bottom:20px;">
                <input type="password" id="pinDigit1" maxlength="1" pattern="[0-9]" inputmode="numeric" style="width:50px; height:60px; text-align:center; font-size:24px; background:#2a2a3e; border:2px solid #444; border-radius:12px; color:#fff;" onkeyup="pinInputHandler(this, 1)">
                <input type="password" id="pinDigit2" maxlength="1" pattern="[0-9]" inputmode="numeric" style="width:50px; height:60px; text-align:center; font-size:24px; background:#2a2a3e; border:2px solid #444; border-radius:12px; color:#fff;" onkeyup="pinInputHandler(this, 2)">
                <input type="password" id="pinDigit3" maxlength="1" pattern="[0-9]" inputmode="numeric" style="width:50px; height:60px; text-align:center; font-size:24px; background:#2a2a3e; border:2px solid #444; border-radius:12px; color:#fff;" onkeyup="pinInputHandler(this, 3)">
                <input type="password" id="pinDigit4" maxlength="1" pattern="[0-9]" inputmode="numeric" style="width:50px; height:60px; text-align:center; font-size:24px; background:#2a2a3e; border:2px solid #444; border-radius:12px; color:#fff;" onkeyup="pinInputHandler(this, 4)">
            </div>
            <p id="pinError" style="color:#ef4444; font-size:12px; margin-bottom:15px; display:none;">PIN incorrect</p>
            <div style="display:flex; gap:10px;">
                <button onclick="closePinModal()" style="flex:1; padding:12px; background:#333; border:none; border-radius:10px; color:#fff; cursor:pointer;">Annuler</button>
                <button onclick="validatePin()" style="flex:1; padding:12px; background:linear-gradient(135deg,#3b82f6,#2563eb); border:none; border-radius:10px; color:#fff; cursor:pointer; font-weight:600;">Valider</button>
            </div>
        </div>
    </div>

    <script src="notification-sound.js"></script>
    <script>
        // PIN Protection - demande le PIN à chaque accès
        const PROTECTED_SECTIONS = ['stats', 'archives'];
        let pendingSection = null;

        function showPinModal(section) {
            pendingSection = section;
            document.getElementById('pinModal').style.display = 'flex';
            document.getElementById('pinDigit1').focus();
            document.getElementById('pinError').style.display = 'none';
            ['pinDigit1','pinDigit2','pinDigit3','pinDigit4'].forEach(id => document.getElementById(id).value = '');
        }

        function closePinModal() {
            document.getElementById('pinModal').style.display = 'none';
            pendingSection = null;
        }

        function pinInputHandler(input, index) {
            if (input.value.length === 1 && index < 4) {
                document.getElementById('pinDigit' + (index + 1)).focus();
            }
            if (input.value.length === 1 && index === 4) {
                validatePin();
            }
            // Backspace
            if (input.value.length === 0 && index > 1) {
                document.getElementById('pinDigit' + (index - 1)).focus();
            }
        }

        function validatePin() {
            const pin = ['pinDigit1','pinDigit2','pinDigit3','pinDigit4'].map(id => document.getElementById(id).value).join('');
            if (pin.length !== 4) return;

            fetch('api/admin-pin.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ action: 'verify', pin })
            }).then(r => r.json()).then(data => {
                if (data.success) {
                    closePinModal();
                    if (pendingSection) {
                        actuallyNavigate(pendingSection);
                    }
                } else {
                    document.getElementById('pinError').style.display = 'block';
                    document.getElementById('pinDigit1').focus();
                    ['pinDigit1','pinDigit2','pinDigit3','pinDigit4'].forEach(id => {
                        document.getElementById(id).value = '';
                        document.getElementById(id).style.borderColor = '#ef4444';
                    });
                    setTimeout(() => {
                        ['pinDigit1','pinDigit2','pinDigit3','pinDigit4'].forEach(id => document.getElementById(id).style.borderColor = '#444');
                    }, 500);
                }
            }).catch(() => {
                document.getElementById('pinError').textContent = 'Erreur de connexion';
                document.getElementById('pinError').style.display = 'block';
            });
        }

        function actuallyNavigate(section) {
            document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
            document.querySelector('[data-section="' + section + '"]').classList.add('active');
            document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
            document.getElementById('section-' + section).classList.add('active');
            window.location.hash = section;
            window.scrollTo(0, 0);
        }

        // Navigation avec protection PIN - toujours demander
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const section = btn.dataset.section;
                if (PROTECTED_SECTIONS.includes(section)) {
                    showPinModal(section);
                    return;
                }
                actuallyNavigate(section);
            });
        });

        // Hash navigation - supporte toutes les sections
        function navigateToSection(section) {
            if (PROTECTED_SECTIONS.includes(section)) {
                showPinModal(section);
                return;
            }
            const btn = document.querySelector('[data-section="' + section + '"]');
            if (btn) actuallyNavigate(section);
        }

        // Charger la section depuis le hash au démarrage
        const hash = window.location.hash.replace('#', '');
        if (hash && document.querySelector('[data-section="' + hash + '"]')) {
            setTimeout(() => navigateToSection(hash), 100);
        }

        // Change PIN
        function changePin() {
            const oldPin = document.getElementById('oldPinInput').value;
            const newPin = document.getElementById('newPinInput').value;
            const result = document.getElementById('pinChangeResult');

            if (!oldPin || oldPin.length < 4) {
                result.textContent = 'Entrez l\'ancien PIN (4 chiffres minimum)';
                result.style.color = '#ef4444';
                result.style.display = 'block';
                return;
            }
            if (!newPin || newPin.length < 4 || !/^\d+$/.test(newPin)) {
                result.textContent = 'Le nouveau PIN doit contenir 4-8 chiffres';
                result.style.color = '#ef4444';
                result.style.display = 'block';
                return;
            }

            fetch('api/admin-pin.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ action: 'change', old_pin: oldPin, new_pin: newPin })
            }).then(r => r.json()).then(data => {
                if (data.success) {
                    result.textContent = '✅ PIN modifié avec succès !';
                    result.style.color = '#10b981';
                    document.getElementById('oldPinInput').value = '';
                    document.getElementById('newPinInput').value = '';
                } else {
                    result.textContent = '❌ ' + (data.message || 'Erreur');
                    result.style.color = '#ef4444';
                }
                result.style.display = 'block';
            }).catch(() => {
                result.textContent = '❌ Erreur de connexion';
                result.style.color = '#ef4444';
                result.style.display = 'block';
            });
        }

        // Restaurant status
        loadRestaurantStatus();
        function loadRestaurantStatus() {
            fetch('api/restaurant-status.php?action=get').then(r => r.json()).then(data => {
                if (data.success) updateStatusUI(data.status.accepting_orders);
            }).catch(() => {});
        }
        function toggleRestaurantStatus() {
            fetch('api/restaurant-status.php?action=toggle', { method: 'POST' }).then(r => r.json()).then(data => {
                if (data.success) { updateStatusUI(data.status.accepting_orders); alert(data.message); }
            });
        }
        function updateStatusUI(isOpen) {
            const card = document.getElementById('restaurant-status-toggle');
            document.getElementById('status-text').textContent = isOpen ? '✅ OUVERT' : '🔒 FERMÉ';
            document.getElementById('status-subtitle').textContent = isOpen ? 'Les clients peuvent commander' : 'Commandes désactivées';
            document.getElementById('status-indicator').innerHTML = isOpen ? '<i class="fas fa-check-circle" style="color:#10b981;"></i>' : '<i class="fas fa-times-circle" style="color:#ef4444;"></i>';
            card.style.borderColor = isOpen ? '#10b981' : '#ef4444';
        }

        // WhatsApp groupé
        function sendGroupWhatsApp() {
            document.getElementById('whatsapp-panel').style.display = document.getElementById('whatsapp-panel').style.display === 'none' ? 'block' : 'none';
        }
        function openWhatsAppLinks() {
            const message = document.getElementById('wa-message').value;
            if (!message) { alert('Entrez un message'); return; }
            const phones = Array.from(document.querySelectorAll('.customer-checkbox:checked')).map(c => c.value);
            if (phones.length === 0) { alert('Sélectionnez au moins un client'); return; }
            phones.forEach((phone, i) => {
                setTimeout(() => {
                    window.open('https://wa.me/' + phone.replace(/[^0-9]/g, '') + '?text=' + encodeURIComponent(message), '_blank');
                }, i * 500);
            });
        }

        // Toggle token visibility
        function toggleTokenVisibility() {
            const input = document.getElementById('whatsapp_token');
            const icon = document.getElementById('toggle-eye');
            if (input.type === 'password') {
                input.type = 'text';
                icon.className = 'fas fa-eye-slash';
            } else {
                input.type = 'password';
                icon.className = 'fas fa-eye';
            }
        }

        // Filtrage des clients
        function filterCustomers(category) {
            const rows = document.querySelectorAll('.customer-row');
            const filters = document.querySelectorAll('.customer-filter');
            const searchTerm = document.getElementById('customerSearch')?.value.toLowerCase() || '';

            // Mettre à jour les boutons de filtre
            filters.forEach(btn => {
                btn.classList.remove('active');
                if (btn.dataset.filter === category) {
                    btn.classList.add('active');
                }
            });

            // Filtrer les clients (combiné avec recherche)
            rows.forEach(row => {
                const matchesCategory = category === 'all' || row.dataset.category === category;
                const matchesSearch = !searchTerm || row.dataset.search.includes(searchTerm);
                row.style.display = (matchesCategory && matchesSearch) ? '' : 'none';
            });
        }

        // Recherche de clients
        function searchCustomers() {
            const searchTerm = document.getElementById('customerSearch').value.toLowerCase();
            const rows = document.querySelectorAll('.customer-row');
            const activeFilter = document.querySelector('.customer-filter.active')?.dataset.filter || 'all';

            rows.forEach(row => {
                const matchesSearch = !searchTerm || row.dataset.search.includes(searchTerm);
                const matchesCategory = activeFilter === 'all' || row.dataset.category === activeFilter;
                row.style.display = (matchesSearch && matchesCategory) ? '' : 'none';
            });
        }

        // FAQ
        function addFaqItem() {
            const container = document.getElementById('faq-items');
            const div = document.createElement('div');
            div.className = 'faq-item';
            div.style.cssText = 'background:#1e293b;padding:12px;border-radius:8px;margin-bottom:10px;';
            div.innerHTML = '<input type="text" name="faq_q[]" placeholder="Question" style="width:100%;padding:8px;background:#2a2a3e;border:1px solid #444;border-radius:6px;color:white;margin-bottom:8px;"><textarea name="faq_a[]" placeholder="Réponse" style="width:100%;padding:8px;background:#2a2a3e;border:1px solid #444;border-radius:6px;color:white;min-height:60px;"></textarea>';
            container.appendChild(div);
        }



        // Notifications
        if (window.orderNotificationSystem) orderNotificationSystem.start(10);

// === GESTION CLIENTS ===
function openAddCustomerModal() {
    document.getElementById('addCustomerModal').style.display = 'flex';
    document.getElementById('newCustomerName').value = '';
    document.getElementById('newCustomerPhone').value = '';
}

function closeAddCustomerModal() {
    document.getElementById('addCustomerModal').style.display = 'none';
}

function submitAddCustomer(event) {
    event.preventDefault();
    
    const name = document.getElementById('newCustomerName').value.trim();
    const phone = document.getElementById('newCustomerPhone').value.trim();
    
    if (!phone) {
        alert('Le numéro de téléphone est requis');
        return;
    }
    
    const formData = new FormData();
    formData.append('action', 'add_customer');
    formData.append('customer_name', name);
    formData.append('customer_phone', phone);
    
    fetch('', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            closeAddCustomerModal();
            window.location.href = 'index.php#customers';
            location.reload();
        } else {
            alert('Erreur: ' + (data.error || 'Impossible d\'ajouter le client'));
        }
    })
    .catch(error => {
        alert('Erreur de connexion');
        console.error(error);
    });
}

function deleteCustomer(customerId, customerName) {
    if (!confirm('Supprimer le client "' + customerName + '" ?\n\nCette action est irréversible.')) {
        return;
    }
    
    const formData = new FormData();
    formData.append('action', 'delete_customer');
    formData.append('customer_id', customerId);
    
    fetch('', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const card = document.getElementById('customer-' + customerId);
            if (card) {
                card.style.transition = 'all 0.3s ease';
                card.style.opacity = '0';
                card.style.transform = 'scale(0.8)';
                setTimeout(() => card.remove(), 300);
            }
        } else {
            alert('Erreur: ' + (data.error || 'Impossible de supprimer le client'));
        }
    })
    .catch(error => {
        alert('Erreur de connexion');
        console.error(error);
    });
}

// Fermer modal en cliquant à l'extérieur
document.getElementById('addCustomerModal')?.addEventListener('click', function(e) {
    if (e.target === this) {
        closeAddCustomerModal();
    }
});

// === GESTION FIDÉLITÉ ===
function updateLoyaltyConfig() {
    const enabled = document.getElementById('loyaltyEnabled').checked;
    const pointsPerEuro = document.getElementById('pointsPerEuro').value;
    
    const formData = new FormData();
    formData.append('action', 'update_loyalty_config');
    formData.append('loyalty_enabled', enabled ? '1' : '0');
    formData.append('points_per_euro', pointsPerEuro);
    
    fetch('', { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
            if (!data.success) alert('Erreur lors de la sauvegarde');
        });
}

function openAddRewardModal() {
    document.getElementById('addRewardModal').style.display = 'flex';
    document.getElementById('rewardName').value = '';
    document.getElementById('rewardDescription').value = '';
    document.getElementById('rewardPoints').value = '100';
    document.getElementById('rewardType').value = 'discount_percent';
    document.getElementById('rewardValue').value = '10';
    toggleRewardValue();
}

function closeAddRewardModal() {
    document.getElementById('addRewardModal').style.display = 'none';
}

function toggleRewardValue() {
    const type = document.getElementById('rewardType').value;
    const container = document.getElementById('rewardValueContainer');
    container.style.display = type === 'free_product' ? 'none' : 'block';
}

function submitAddReward(event) {
    event.preventDefault();
    
    const formData = new FormData();
    formData.append('action', 'add_reward');
    formData.append('reward_name', document.getElementById('rewardName').value);
    formData.append('reward_description', document.getElementById('rewardDescription').value);
    formData.append('points_required', document.getElementById('rewardPoints').value);
    formData.append('reward_type', document.getElementById('rewardType').value);
    formData.append('reward_value', document.getElementById('rewardValue').value);
    
    fetch('', { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                closeAddRewardModal();
                window.location.href = 'index.php#loyalty';
                location.reload();
            } else {
                alert('Erreur: ' + (data.error || 'Impossible de créer la récompense'));
            }
        });
}

function deleteReward(rewardId) {
    if (!confirm('Supprimer cette récompense ?')) return;

    const formData = new FormData();
    formData.append('action', 'delete_reward');
    formData.append('reward_id', rewardId);

    fetch('', { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                window.location.href = 'index.php#loyalty';
                location.reload();
            } else {
                alert('Erreur lors de la suppression');
            }
        });
}

// Fermer modal récompense en cliquant dehors
document.getElementById('addRewardModal')?.addEventListener('click', function(e) {
    if (e.target === this) closeAddRewardModal();
});

// Fermer modal points en cliquant dehors
document.getElementById('addPointsModal')?.addEventListener('click', function(e) {
    if (e.target === this) closeAddPointsModal();
});

// === GESTION DIFFUSION ===
function toggleBroadcastPanel() {
    const panel = document.getElementById('whatsapp-panel');
    const checkboxes = document.querySelectorAll('.broadcast-cb');

    if (panel.style.display === 'none') {
        panel.style.display = 'block';
        checkboxes.forEach(cb => cb.style.display = 'inline-block');
    } else {
        panel.style.display = 'none';
        checkboxes.forEach(cb => cb.style.display = 'none');
        deselectAllCustomers();
    }
}

function selectAllCustomers() {
    document.querySelectorAll('.customer-checkbox').forEach(cb => {
        const row = cb.closest('.customer-row');
        if (row && row.style.display !== 'none') {
            cb.checked = true;
        }
    });
    updateSelectedCount();
}

function deselectAllCustomers() {
    document.querySelectorAll('.customer-checkbox').forEach(cb => cb.checked = false);
    updateSelectedCount();
}

function toggleAllCustomers(masterCheckbox) {
    if (masterCheckbox.checked) {
        selectAllCustomers();
    } else {
        deselectAllCustomers();
    }
}

function updateSelectedCount() {
    const count = document.querySelectorAll('.customer-checkbox:checked').length;
    document.getElementById('selected-count').textContent = count;
}

// === GESTION POINTS MANUELS ===
function openAddPointsModal(customerId, customerName) {
    document.getElementById('pointsCustomerId').value = customerId;
    document.getElementById('pointsCustomerName').textContent = customerName;
    document.getElementById('pointsAmount').value = 10;
    document.getElementById('addPointsModal').style.display = 'flex';
}

function closeAddPointsModal() {
    document.getElementById('addPointsModal').style.display = 'none';
}

function submitAddPoints(event) {
    event.preventDefault();

    const customerId = document.getElementById('pointsCustomerId').value;
    const points = document.getElementById('pointsAmount').value;

    const formData = new FormData();
    formData.append('action', 'add_loyalty_points');
    formData.append('customer_id', customerId);
    formData.append('points', points);

    fetch('', { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                closeAddPointsModal();
                window.location.href = 'index.php#customers';
                location.reload();
            } else {
                alert('Erreur: ' + (data.error || 'Impossible d\'ajouter les points'));
            }
        })
        .catch(error => {
            alert('Erreur de connexion');
            console.error(error);
        });
}

// === MODAL UTILISER POINTS (REDEEM) ===
let selectedRedeemCustomer = null;
const availableRewards = <?php echo json_encode($rewards ?? []); ?>;

function openRedeemModal() {
    document.getElementById('redeemModal').style.display = 'flex';
    document.getElementById('redeemSearchInput').value = '';
    document.getElementById('redeemSearchResults').innerHTML = '';
    document.getElementById('redeemSelectedCustomer').style.display = 'none';
    document.getElementById('redeemRewardsSection').style.display = 'none';
    document.getElementById('redeemNoRewards').style.display = 'none';
    selectedRedeemCustomer = null;
    setTimeout(() => document.getElementById('redeemSearchInput').focus(), 100);
}

function closeRedeemModal() {
    document.getElementById('redeemModal').style.display = 'none';
}

let searchTimeout = null;
function searchCustomerForRedeem(query) {
    clearTimeout(searchTimeout);
    const resultsDiv = document.getElementById('redeemSearchResults');

    if (query.length < 2) {
        resultsDiv.innerHTML = '<p style="color: #6b7280; font-size: 13px; padding: 10px;">Tapez au moins 2 caractères...</p>';
        return;
    }

    resultsDiv.innerHTML = '<p style="color: #9ca3af; font-size: 13px; padding: 10px;"><i class="fas fa-spinner fa-spin"></i> Recherche...</p>';

    searchTimeout = setTimeout(() => {
        const formData = new FormData();
        formData.append('action', 'search_customer');
        formData.append('query', query);

        fetch('', { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
                if (data.success && data.customers.length > 0) {
                    resultsDiv.innerHTML = data.customers.map(c => `
                        <div onclick="selectCustomerForRedeem(${c.id}, '${c.name.replace(/'/g, "\\'")}', '${c.phone}', '${c.loyalty_code || ''}', ${c.loyalty_points || 0})"
                             style="padding: 12px; background: #1e293b; border-radius: 8px; margin-bottom: 8px; cursor: pointer; border: 1px solid #374151; transition: all 0.2s;"
                             onmouseover="this.style.borderColor='#10b981'" onmouseout="this.style.borderColor='#374151'">
                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <div>
                                    <div style="font-weight: 600;">${c.name}</div>
                                    <div style="color: #9ca3af; font-size: 12px;">${c.phone}</div>
                                    <div style="color: #f59e0b; font-size: 11px;">${c.loyalty_code || 'N/A'}</div>
                                </div>
                                <div style="text-align: right;">
                                    <div style="font-size: 20px; font-weight: bold; color: #f59e0b;">${c.loyalty_points || 0}</div>
                                    <div style="color: #6b7280; font-size: 10px;">points</div>
                                </div>
                            </div>
                        </div>
                    `).join('');
                } else {
                    resultsDiv.innerHTML = '<p style="color: #6b7280; font-size: 13px; padding: 10px;">Aucun client trouvé</p>';
                }
            })
            .catch(err => {
                resultsDiv.innerHTML = '<p style="color: #ef4444; font-size: 13px; padding: 10px;">Erreur de recherche</p>';
                console.error(err);
            });
    }, 300);
}

function selectCustomerForRedeem(id, name, phone, code, points) {
    selectedRedeemCustomer = { id, name, phone, code, points };

    // Masquer recherche
    document.getElementById('redeemSearchResults').innerHTML = '';
    document.getElementById('redeemSearchInput').value = '';

    // Afficher client sélectionné
    document.getElementById('redeemSelectedCustomer').style.display = 'block';
    document.getElementById('redeemCustomerName').textContent = name;
    document.getElementById('redeemCustomerPhone').textContent = phone;
    document.getElementById('redeemCustomerCode').textContent = code || 'N/A';
    document.getElementById('redeemCustomerPoints').textContent = points;
    document.getElementById('redeemCustomerId').value = id;

    // Afficher récompenses disponibles
    const rewardsList = document.getElementById('redeemRewardsList');
    const rewardsSection = document.getElementById('redeemRewardsSection');
    const noRewards = document.getElementById('redeemNoRewards');

    const affordable = availableRewards.filter(r => points >= r.points_required);

    if (affordable.length > 0) {
        rewardsSection.style.display = 'block';
        noRewards.style.display = 'none';

        rewardsList.innerHTML = affordable.map(r => `
            <div style="padding: 15px; background: #1e293b; border-radius: 10px; margin-bottom: 10px; border-left: 4px solid #10b981;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <div style="font-weight: 600; margin-bottom: 2px;">${r.name}</div>
                        <div style="color: #9ca3af; font-size: 12px;">${r.description || ''}</div>
                    </div>
                    <div style="text-align: right;">
                        <div style="color: #f59e0b; font-weight: bold;">${r.points_required} pts</div>
                        <button onclick="redeemReward(${r.id}, '${r.name.replace(/'/g, "\\'")}', ${r.points_required})"
                                style="margin-top: 5px; padding: 6px 12px; background: #10b981; border: none; border-radius: 6px; color: white; font-size: 12px; cursor: pointer;">
                            <i class="fas fa-gift"></i> Utiliser
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
    } else {
        rewardsSection.style.display = 'none';
        noRewards.style.display = 'block';
    }
}

function redeemReward(rewardId, rewardName, pointsRequired) {
    if (!selectedRedeemCustomer) {
        alert('Aucun client sélectionné');
        return;
    }

    if (!confirm(`Utiliser ${pointsRequired} points pour "${rewardName}" ?`)) {
        return;
    }

    const formData = new FormData();
    formData.append('action', 'redeem_reward');
    formData.append('customer_id', selectedRedeemCustomer.id);
    formData.append('reward_id', rewardId);

    fetch('', { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                alert(`✓ Récompense utilisée !\n${data.reward_name}\nPoints restants: ${data.new_points}`);
                closeRedeemModal();
                window.location.href = 'index.php#loyalty';
                location.reload();
            } else {
                alert('Erreur: ' + (data.error || 'Impossible d\'utiliser la récompense'));
            }
        })
        .catch(err => {
            alert('Erreur de connexion');
            console.error(err);
        });
}

// === GESTION QR CODE FIDÉLITÉ ===
function copyLoyaltyUrl() {
    const url = document.getElementById('loyalty-url').value;
    navigator.clipboard.writeText(url).then(() => {
        alert('Lien copié !');
    }).catch(() => {
        // Fallback
        const input = document.getElementById('loyalty-url');
        input.select();
        document.execCommand('copy');
        alert('Lien copié !');
    });
}

function printQRCode() {
    const qrDiv = document.getElementById('loyalty-qrcode');
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
        <html>
        <head>
            <title>QR Code Fidélité</title>
            <style>
                body { display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; font-family: Arial, sans-serif; }
                .container { text-align: center; }
                .qr { margin: 20px auto; }
                h2 { color: #f59e0b; }
            </style>
        </head>
        <body>
            <div class="container">
                <h2>Carte de Fidélité</h2>
                <div class="qr">${qrDiv.innerHTML}</div>
                <p>Scannez pour accéder à votre carte fidélité</p>
            </div>
        </body>
        </html>
    `);
    printWindow.document.close();
    printWindow.print();
}

// Amélioration du style du switch pour la fidélité
document.querySelectorAll('.switch input[type="checkbox"]').forEach(input => {
    const slider = input.nextElementSibling;
    if (slider) {
        const updateSlider = () => {
            slider.style.backgroundColor = input.checked ? '#f59e0b' : '#374151';
            slider.innerHTML = input.checked
                ? '<span style="position:absolute;left:4px;top:3px;width:20px;height:20px;background:white;border-radius:50%;transition:.4s;transform:translateX(24px);"></span>'
                : '<span style="position:absolute;left:4px;top:3px;width:20px;height:20px;background:white;border-radius:50%;transition:.4s;"></span>';
        };
        updateSlider();
        input.addEventListener('change', updateSlider);
    }
});

// ===== Gestion Livraison & Plateformes =====
function toggleDelivery() {
    fetch('api/restaurant-status.php?action=toggle_delivery', { method: 'POST' })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                const bg = document.getElementById('delivery-toggle-bg');
                const knob = document.getElementById('delivery-toggle-knob');
                if (data.delivery_enabled) {
                    bg.style.background = '#10b981';
                    knob.style.left = '26px';
                } else {
                    bg.style.background = '#4b5563';
                    knob.style.left = '2px';
                }
                showToast(data.message || 'Livraison mise à jour');
            } else {
                showToast(data.error || 'Erreur', 'error');
            }
        })
        .catch(() => showToast('Erreur réseau', 'error'));
}

function togglePlatform(platformId) {
    fetch('api/restaurant-status.php?action=update_platform', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ platform_id: platformId })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            const row = document.querySelector(`.platform-row[data-id="${platformId}"]`);
            if (row) {
                const toggle = row.querySelector('.platform-toggle');
                const platform = data.platforms.find(p => p.id === platformId);
                if (platform && toggle) {
                    toggle.style.background = platform.enabled ? '#10b981' : '#4b5563';
                    toggle.querySelector('div').style.left = platform.enabled ? '20px' : '2px';
                }
            }
            showToast('Plateforme mise à jour');
        } else {
            showToast(data.error || 'Erreur', 'error');
        }
    })
    .catch(() => showToast('Erreur réseau', 'error'));
}

function openAddPlatformModal() {
    document.getElementById('add-platform-modal').style.display = 'flex';
    document.getElementById('new-platform-name').value = '';
    document.getElementById('new-platform-url').value = '';
}

function closeAddPlatformModal() {
    document.getElementById('add-platform-modal').style.display = 'none';
}

function addPlatform() {
    const name = document.getElementById('new-platform-name').value.trim();
    const url = document.getElementById('new-platform-url').value.trim();

    if (!name || !url) {
        showToast('Remplissez tous les champs', 'error');
        return;
    }

    fetch('api/restaurant-status.php?action=add_platform', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, url })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            closeAddPlatformModal();
            location.reload(); // Reload to show new platform
        } else {
            showToast(data.error || 'Erreur', 'error');
        }
    })
    .catch(() => showToast('Erreur réseau', 'error'));
}

function deletePlatform(platformId) {
    if (!confirm('Supprimer cette plateforme ?')) return;

    fetch('api/restaurant-status.php?action=delete_platform', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ platform_id: platformId })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            const row = document.querySelector(`.platform-row[data-id="${platformId}"]`);
            if (row) row.remove();
            showToast('Plateforme supprimée');
        } else {
            showToast(data.error || 'Erreur', 'error');
        }
    })
    .catch(() => showToast('Erreur réseau', 'error'));
}

// ===== Export CSV par mois =====
function exportArchives() {
    const month = document.getElementById('exportMonth').value;
    let url = '?export=archives';
    if (month) {
        url += '&month=' + encodeURIComponent(month);
    }
    window.location.href = url;
}


    </script>
</body>
</html>
